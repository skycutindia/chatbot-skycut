@extends('layouts.app')

@section('title', 'Canned responses')

@section('content')
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold">Canned responses</h1>
    <p class="text-slate-400 mt-1">Quick replies for live agent conversations</p>

    <ul class="mt-6 space-y-2">
        @foreach($responses as $response)
            <li class="flex justify-between items-start rounded-xl bg-slate-900 border border-slate-800 p-4">
                <div>
                    <p class="font-medium">{{ $response->title }} @if($response->shortcut)<span class="text-slate-500 text-xs">/{{ $response->shortcut }}</span>@endif</p>
                    <p class="text-sm text-slate-400 mt-1">{{ Str::limit($response->body, 120) }}</p>
                </div>
                <form method="POST" action="{{ route('canned-responses.destroy', $response) }}">@csrf @method('DELETE')<button class="text-red-400 text-sm">Delete</button></form>
            </li>
        @endforeach
    </ul>

    <form method="POST" action="{{ route('canned-responses.store') }}" class="mt-8 rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-3">
        @csrf
        <input name="title" placeholder="Title" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <input name="shortcut" placeholder="Shortcut (optional)" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <textarea name="body" rows="3" placeholder="Response text..." required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm"></textarea>
        <button class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Add response</button>
    </form>
</div>
@endsection
