<?php

namespace App\View\Composers;

use App\Models\Conversation;
use Illuminate\View\View;

class DashboardComposer
{
    public function compose(View $view): void
    {
        if (! auth()->check() || auth()->user()->roleEnum()->isPlatformLevel()) {
            $view->with('awaitingCount', 0);

            return;
        }

        $orgId = auth()->user()->organization_id;

        $awaitingCount = Conversation::query()
            ->where('status', 'awaiting_agent')
            ->when($orgId, fn ($q) => $q->whereHas('website', fn ($w) => $w->where('organization_id', $orgId)))
            ->count();

        $view->with('awaitingCount', $awaitingCount);
    }
}
