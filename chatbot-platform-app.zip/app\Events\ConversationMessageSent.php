<?php

namespace App\Events;

use App\Models\Message;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ConversationMessageSent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public Message $message,
    ) {
        $this->message->loadMissing('conversation.website');
    }

    /** @return array<int, PrivateChannel> */
    public function broadcastOn(): array
    {
        $orgId = $this->message->conversation->website->organization_id;

        return [
            new PrivateChannel('organization.'.$orgId),
            new PrivateChannel('conversation.'.$this->message->conversation_id),
        ];
    }

    public function broadcastAs(): string
    {
        return 'message.sent';
    }

    /** @return array<string, mixed> */
    public function broadcastWith(): array
    {
        return [
            'id' => $this->message->id,
            'conversation_id' => $this->message->conversation_id,
            'website_id' => $this->message->conversation->website_id,
            'content' => $this->message->content,
            'sender_type' => $this->message->sender_type,
            'source' => $this->message->source,
            'created_at' => $this->message->created_at?->toIso8601String(),
        ];
    }
}
