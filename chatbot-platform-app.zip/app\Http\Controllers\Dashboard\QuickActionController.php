<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\QuickAction;
use App\Models\Website;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class QuickActionController extends Controller
{
    public function index(Website $website): View
    {
        $website->load('quickActions');

        return view('dashboard.websites.quick-actions', compact('website'));
    }

    public function store(Request $request, Website $website): RedirectResponse
    {
        $validated = $request->validate([
            'label' => 'required|string|max:120',
            'icon' => 'nullable|string|max:64',
            'action_type' => 'required|in:url,email,phone,internal',
            'action_value' => 'nullable|string|max:2048',
            'sort_order' => 'nullable|integer|min:0',
        ]);

        $website->quickActions()->create($validated);

        return back()->with('success', 'Quick action added.');
    }

    public function destroy(Website $website, QuickAction $quickAction): RedirectResponse
    {
        abort_unless($quickAction->website_id === $website->id, 404);
        $quickAction->delete();

        return back()->with('success', 'Quick action removed.');
    }
}
