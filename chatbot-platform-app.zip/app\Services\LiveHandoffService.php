<?php

namespace App\Services;

use App\Events\ConversationAwaitingAgent;
use App\Events\ConversationUpdated;
use App\Models\Conversation;
use App\Models\User;
use App\Models\Website;
use Illuminate\Support\Str;

class LiveHandoffService
{
    public function __construct(
        protected LeadCaptureService $leadCapture,
    ) {}

    public function shouldHandoff(Website $website, string $userMessage, float $confidence, string $source): bool
    {
        $config = $website->configuration;
        $triggers = $config->handoff_triggers ?? config('chatbot.default_handoff_triggers', []);
        $normalized = Str::lower($userMessage);

        foreach ($triggers['keywords'] ?? ['human', 'agent', 'speak to someone', 'live chat'] as $keyword) {
            if (Str::contains($normalized, Str::lower($keyword))) {
                return true;
            }
        }

        if ($source === 'ai' && $confidence < (float) $config->confidence_threshold) {
            return true;
        }

        return false;
    }

    public function initiate(Website $website, Conversation $conversation, string $reason = 'low_confidence'): Conversation
    {
        $conversation->update([
            'status' => 'awaiting_agent',
            'mode' => 'human',
            'sla_due_at' => now()->addMinutes(config('chatbot.sla_minutes', 15)),
        ]);

        $lead = $this->leadCapture->captureFromConversation($website, $conversation);

        $agent = $this->assignAvailableAgent($website);
        if ($agent) {
            $conversation->update(['assigned_user_id' => $agent->id]);
            $lead->update(['assigned_user_id' => $agent->id]);
        }

        event(new ConversationAwaitingAgent($conversation, $reason));
        broadcast(new ConversationUpdated($conversation->fresh(), 'handoff'));

        return $conversation->fresh();
    }

    public function returnToAi(Conversation $conversation): Conversation
    {
        $conversation->update([
            'status' => 'open',
            'mode' => 'ai',
            'assigned_user_id' => null,
        ]);

        broadcast(new ConversationUpdated($conversation->fresh(), 'return_to_ai'));

        return $conversation->fresh();
    }

    protected function assignAvailableAgent(Website $website): ?User
    {
        return User::query()
            ->where('organization_id', $website->organization_id)
            ->where('is_active', true)
            ->whereIn('role', ['agent', 'manager', 'admin', 'owner'])
            ->orderBy('id')
            ->first();
    }
}
