﻿@extends('layouts.app')

@section('title', 'New Website')

@section('content')
<div class="max-w-xl mx-auto">
    <h1 class="text-3xl font-bold">Create website</h1>
    <p class="text-slate-400 mt-1">A unique bot token and embed snippet will be generated automatically.</p>

    <form method="POST" action="{{ route('websites.store') }}" class="mt-8 space-y-4 bg-slate-900 border border-slate-800 rounded-2xl p-8">
        @csrf
        <div>
            <label class="block text-sm text-slate-400 mb-1">Website name</label>
            <input type="text" name="name" value="{{ old('name') }}" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white">
        </div>
        <div>
            <label class="block text-sm text-slate-400 mb-1">Website URL</label>
            <input type="url" name="url" value="{{ old('url') }}" placeholder="https://example.com" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white">
        </div>
        <div>
            <label class="block text-sm text-slate-400 mb-1">Allowed domain (optional)</label>
            <input type="text" name="domain" value="{{ old('domain') }}" placeholder="example.com" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white">
        </div>
        <button type="submit" class="w-full py-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 font-medium">Create chatbot</button>
    </form>
</div>
@endsection


