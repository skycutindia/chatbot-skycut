@php
    $initials = collect(explode(' ', auth()->user()->name))->map(fn ($p) => strtoupper(substr($p, 0, 1)))->take(2)->join('');
    $awaitingCount = $awaitingCount ?? 0;
@endphp
<header class="dash-header">
    <button type="button" id="mobile-nav-toggle" class="dash-icon-btn lg:hidden" aria-label="Menu">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
    </button>

    <div class="dash-global-search" id="global-search-wrap">
        <input
            id="global-search"
            type="text"
            placeholder="Search conversations, leads, websites..."
            value="{{ request('q') }}"
            class="dash-input dash-global-search-input"
            autocomplete="off"
            aria-label="Search conversations, leads, websites"
        >
        <div id="search-results" class="dash-search-results hidden"></div>
    </div>

    <div class="dash-header-actions">
        @if(auth()->user()->roleEnum()->canHandleLiveChat())
            <a href="{{ route('inbox.index') }}" class="dash-icon-btn relative" title="Live inbox">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.75" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                @if($awaitingCount > 0)
                    <span class="dash-notify-dot">{{ $awaitingCount > 9 ? '9+' : $awaitingCount }}</span>
                @endif
            </a>
        @endif

        <button type="button" id="theme-toggle" class="dash-icon-btn" title="Toggle light/dark theme" aria-label="Toggle light/dark theme">
            <svg class="dash-theme-icon dash-theme-icon-light" fill="none" stroke="currentColor" stroke-width="1.75" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
            <svg class="dash-theme-icon dash-theme-icon-dark hidden" fill="none" stroke="currentColor" stroke-width="1.75" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
        </button>

        <div class="relative">
            <button type="button" id="user-menu-button" class="dash-user-btn">
                <span class="dash-user-avatar">{{ $initials }}</span>
                <span class="dash-user-meta hidden md:block">
                    <span class="dash-user-name">{{ auth()->user()->name }}</span>
                    <span class="dash-user-role">{{ auth()->user()->roleEnum()->label() }}</span>
                </span>
                <svg class="dash-user-chevron hidden md:block" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>
            </button>
            <div id="user-menu" class="dash-dropdown hidden absolute right-0 mt-2 w-56 rounded-xl py-2 z-50">
                <div class="px-4 py-2 border-b border-[var(--dash-border)]">
                    <p class="text-sm font-semibold">{{ auth()->user()->name }}</p>
                    <p class="text-xs dash-muted truncate">{{ auth()->user()->email }}</p>
                </div>
                <a href="{{ route('settings.profile.edit') }}" class="block px-4 py-2.5 text-sm hover:bg-[var(--dash-hover)]">My profile</a>
                @if(auth()->user()->roleEnum()->canManageOrganization())
                    <a href="{{ route('settings.organization.edit') }}" class="block px-4 py-2.5 text-sm hover:bg-[var(--dash-hover)]">Organization</a>
                @endif
                <form method="POST" action="{{ route('logout') }}" class="border-t border-[var(--dash-border)] mt-1 pt-1">
                    @csrf
                    <button type="submit" class="dash-btn-signout w-full text-left px-4 py-2.5 text-sm">Sign out</button>
                </form>
            </div>
        </div>
    </div>
</header>
