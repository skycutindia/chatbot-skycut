<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $website->name }} — AI-Powered Customer Support</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
                    colors: {
                        brand: {
                            DEFAULT: '{{ $website->configuration->primary_color ?? '#0d9488' }}',
                            light: '{{ $website->configuration->secondary_color ?? '#14b8a6' }}',
                            50: '#f0fdfa',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .hero-gradient {
            background: radial-gradient(ellipse 80% 60% at 70% 20%, rgba(20, 184, 166, 0.15), transparent),
                        radial-gradient(ellipse 60% 50% at 20% 80%, rgba(13, 148, 136, 0.1), transparent),
                        linear-gradient(180deg, #f0fdfa 0%, #ffffff 100%);
        }
        .chat-host { min-height: 420px; height: 100%; }
    </style>
</head>
<body class="font-sans text-slate-900 antialiased bg-white">

{{-- Header --}}
<header class="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-100">
    <div class="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <a href="/" class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-brand to-brand-light flex items-center justify-center text-white shadow-lg shadow-teal-500/20">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="3"/><path d="M8 15h.01M16 15h.01"/></svg>
            </div>
            <span class="text-xl font-bold text-brand">{{ $website->name }}</span>
        </a>
        <nav class="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            <a href="#features" class="hover:text-brand transition">Features</a>
            <a href="#pricing" class="hover:text-brand transition">Pricing</a>
            <a href="{{ route('login') }}" class="hover:text-brand transition">Admin</a>
        </nav>
        <button type="button" class="md:hidden p-2 text-slate-600" aria-label="Menu">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
    </div>
</header>

{{-- Hero --}}
<section class="hero-gradient overflow-hidden">
    <div class="max-w-6xl mx-auto px-6 py-16 md:py-24 grid lg:grid-cols-2 gap-12 items-center">
        <div>
            <h1 class="text-4xl md:text-5xl lg:text-[3.25rem] font-extrabold leading-[1.1] tracking-tight text-slate-900">
                AI-Powered Customer Support That Never Sleeps
            </h1>
            <p class="mt-6 text-lg text-slate-600 leading-relaxed max-w-lg">
                Deploy intelligent chatbots on your website in minutes. Reduce support costs by 80% while delighting customers 24/7 with <strong>{{ $website->configuration->bot_name }}</strong>.
            </p>
            <div class="mt-8 flex flex-wrap gap-4">
                <a href="#pricing" class="px-7 py-3.5 rounded-xl bg-brand text-white font-semibold shadow-lg shadow-teal-500/30 hover:bg-teal-700 transition">
                    Start Free Trial
                </a>
                <a href="#features" class="px-7 py-3.5 rounded-xl border-2 border-slate-200 font-semibold text-slate-700 hover:border-brand hover:text-brand transition">
                    Watch Demo
                </a>
            </div>
            <p class="mt-6 text-sm text-slate-500">
                Admin: <a href="{{ route('login') }}" class="text-brand font-medium hover:underline">sign in to dashboard</a>
            </p>
        </div>

        {{-- Inline live chat preview --}}
        <div class="relative">
            <div class="absolute -inset-4 bg-gradient-to-r from-brand/10 to-teal-200/20 rounded-3xl blur-2xl"></div>
            <div class="relative rounded-3xl border border-slate-200/80 bg-white shadow-2xl shadow-slate-200/50 overflow-hidden">
                <div id="hero-chat-widget" class="chat-host h-[480px]"></div>
            </div>
            <div class="absolute -bottom-4 -right-2 md:right-4 bg-white rounded-2xl shadow-xl border border-slate-100 px-5 py-3 flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center text-brand">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                </div>
                <div>
                    <p class="text-sm font-semibold text-slate-900">Satisfaction</p>
                    <p class="text-sm font-bold text-green-500">98.5% positive</p>
                </div>
            </div>
        </div>
    </div>
</section>

{{-- Features --}}
<section id="features" class="py-20 bg-white">
    <div class="max-w-6xl mx-auto px-6">
        <div class="text-center max-w-2xl mx-auto mb-14">
            <h2 class="text-3xl md:text-4xl font-bold">Everything You Need to Delight Customers</h2>
            <p class="mt-4 text-slate-600 text-lg">Powerful tools designed to transform your customer support experience.</p>
        </div>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach([
                ['title' => 'AI Chatbot', 'desc' => 'Smart responses powered by GPT, trained on your content. Human-like conversations.', 'path' => 'M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z'],
                ['title' => 'Live Agent Handoff', 'desc' => 'Seamlessly transfer to human agents when needed. Real-time context sharing.', 'path' => 'M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z'],
                ['title' => 'Knowledge Base', 'desc' => 'Train your bot with docs, FAQs, and website content. Always up to date.', 'path' => 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253'],
                ['title' => 'Analytics Dashboard', 'desc' => 'Track conversations, satisfaction, and AI performance with actionable insights.', 'path' => 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z'],
                ['title' => 'Multi-Channel', 'desc' => 'Embed on website, WhatsApp, Telegram, and more. Reach customers everywhere.', 'path' => 'M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z'],
                ['title' => 'Custom Branding', 'desc' => 'Match your brand with colors, logos, and themes. Feels native to your site.', 'path' => 'M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01'],
            ] as $feature)
                <div class="group rounded-2xl border border-slate-200 p-7 hover:border-brand/30 hover:shadow-lg hover:shadow-teal-500/5 transition-all duration-300">
                    <div class="w-12 h-12 rounded-xl bg-brand-50 text-brand flex items-center justify-center mb-5 group-hover:bg-brand group-hover:text-white transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="{{ $feature['path'] }}"/></svg>
                    </div>
                    <h3 class="text-lg font-bold mb-2">{{ $feature['title'] }}</h3>
                    <p class="text-slate-600 text-sm leading-relaxed">{{ $feature['desc'] }}</p>
                </div>
            @endforeach
        </div>
    </div>
</section>

{{-- Pricing --}}
<section id="pricing" class="py-20 bg-slate-50">
    <div class="max-w-6xl mx-auto px-6">
        <div class="text-center max-w-2xl mx-auto mb-14">
            <h2 class="text-3xl md:text-4xl font-bold">Simple, Transparent Pricing</h2>
            <p class="mt-4 text-slate-600">Start free and scale as you grow. No hidden fees.</p>
        </div>
        <div class="grid md:grid-cols-3 gap-6">
            @foreach([
                ['plan' => 'Free', 'tagline' => 'Perfect for trying out', 'price' => '$0', 'features' => ['100 chats/mo', '1 website', '1 agent', 'Basic AI responses', 'Community support'], 'popular' => false],
                ['plan' => 'Pro', 'tagline' => 'Best for growing businesses', 'price' => '$49', 'features' => ['5,000 chats/mo', '5 websites', '5 agents', 'Advanced AI (GPT-4)', 'Live agent handoff', 'Custom branding'], 'popular' => true],
                ['plan' => 'Enterprise', 'tagline' => 'For large-scale operations', 'price' => 'Custom', 'features' => ['Unlimited chats', 'Unlimited websites', 'Custom AI training', 'API access', 'SSO & SAML', '24/7 priority support'], 'popular' => false],
            ] as $tier)
                <div class="rounded-2xl bg-white border {{ $tier['popular'] ? 'border-brand ring-2 ring-brand/20 shadow-xl' : 'border-slate-200' }} p-8 relative flex flex-col">
                    @if($tier['popular'])
                        <span class="absolute -top-3 left-1/2 -translate-x-1/2 bg-brand text-white text-xs font-bold px-4 py-1 rounded-full">Most Popular</span>
                    @endif
                    <h3 class="text-xl font-bold">{{ $tier['plan'] }}</h3>
                    <p class="text-sm text-slate-500 mt-1">{{ $tier['tagline'] }}</p>
                    <p class="mt-6 text-4xl font-extrabold">{{ $tier['price'] }}@if($tier['price'] !== 'Custom')<span class="text-base font-normal text-slate-500">/mo</span>@endif</p>
                    <ul class="mt-8 space-y-3 flex-1">
                        @foreach($tier['features'] as $f)
                            <li class="flex items-start gap-2 text-sm text-slate-600">
                                <svg class="w-5 h-5 text-brand shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"/></svg>
                                {{ $f }}
                            </li>
                        @endforeach
                    </ul>
                    <button type="button" class="mt-8 w-full py-3 rounded-xl font-semibold {{ $tier['popular'] ? 'bg-brand text-white hover:bg-teal-700' : 'border-2 border-slate-200 hover:border-brand hover:text-brand' }} transition">
                        {{ $tier['plan'] === 'Enterprise' ? 'Contact Sales' : 'Get Started' }}
                    </button>
                </div>
            @endforeach
        </div>
    </div>
</section>

{{-- CTA --}}
<section class="py-20 bg-gradient-to-br from-brand to-teal-600 text-white">
    <div class="max-w-3xl mx-auto px-6 text-center">
        <h2 class="text-3xl md:text-4xl font-bold">Ready to transform your support?</h2>
        <p class="mt-4 text-teal-100 text-lg">Join thousands of teams using AI chatbots to delight customers.</p>
        <div class="mt-8 flex flex-wrap justify-center gap-4">
            <a href="{{ route('login') }}" class="px-8 py-3.5 rounded-xl bg-white text-brand font-bold hover:bg-teal-50 transition">Open Admin Dashboard</a>
            <a href="#hero-chat-widget" class="px-8 py-3.5 rounded-xl border-2 border-white/40 font-semibold hover:bg-white/10 transition">Try Live Chat</a>
        </div>
    </div>
</section>

{{-- Footer --}}
<footer class="bg-slate-900 text-slate-400 py-14">
    <div class="max-w-6xl mx-auto px-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
            <div class="flex items-center gap-2 text-white font-bold text-lg mb-4">
                <div class="w-8 h-8 rounded-lg bg-brand flex items-center justify-center">
                    <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="3"/></svg>
                </div>
                {{ $website->name }}
            </div>
            <p class="text-sm leading-relaxed">AI-powered customer support that helps businesses delight their customers 24/7.</p>
        </div>
        @foreach(['Product' => ['Features', 'Pricing', 'Integrations', 'API Docs'], 'Company' => ['About', 'Blog', 'Careers', 'Contact'], 'Resources' => ['Documentation', 'Help Center', 'Community', 'Status']] as $heading => $links)
            <div>
                <h4 class="text-white font-semibold mb-4">{{ $heading }}</h4>
                <ul class="space-y-2 text-sm">
                    @foreach($links as $link)
                        <li><a href="#" class="hover:text-white transition">{{ $link }}</a></li>
                    @endforeach
                </ul>
            </div>
        @endforeach
    </div>
    <div class="max-w-6xl mx-auto px-6 mt-12 pt-8 border-t border-slate-800 text-sm text-center">
        © {{ date('Y') }} {{ $website->name }}. Demo powered by AI Chatbot Hub Pro.
    </div>
</footer>

{{-- Inline hero chat --}}
<script src="{{ rtrim(config('app.url'), '/') }}/widget/chatbot.js"
        data-bot-token="{{ $website->bot_token }}"
        data-inline="#hero-chat-widget"
        data-auto-open="true"
        async></script>
</body>
</html>
