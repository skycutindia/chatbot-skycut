<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Conversation extends Model
{
    protected $fillable = [
        'website_id', 'visitor_id', 'visitor_name', 'visitor_email', 'visitor_phone', 'visitor_company',
        'status', 'mode', 'priority', 'tags', 'sla_due_at',
        'assigned_user_id', 'page_url', 'source_url', 'metadata',
        'ip_address', 'user_agent', 'utm_params',
        'last_message_at', 'closed_at',
    ];

    protected function casts(): array
    {
        return [
            'metadata' => 'array',
            'tags' => 'array',
            'utm_params' => 'array',
            'last_message_at' => 'datetime',
            'closed_at' => 'datetime',
            'sla_due_at' => 'datetime',
        ];
    }

    public function website(): BelongsTo
    {
        return $this->belongsTo(Website::class);
    }

    public function assignedUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_user_id');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(Message::class)->orderBy('created_at');
    }

    public function internalNotes(): HasMany
    {
        return $this->hasMany(ConversationNote::class);
    }

    public function lead(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(Lead::class);
    }

    public function rating(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(ConversationRating::class);
    }

    public function isAwaitingAgent(): bool
    {
        return $this->mode === 'human' || $this->status === 'awaiting_agent';
    }

    public function isOpen(): bool
    {
        return $this->status === 'open' || $this->status === 'awaiting_agent';
    }
}
