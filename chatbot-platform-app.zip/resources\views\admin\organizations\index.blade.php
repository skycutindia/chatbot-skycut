@extends('layouts.app')

@section('title', 'Organizations')

@section('content')
<div class="max-w-6xl mx-auto">
    <h1 class="text-3xl font-bold">Organizations</h1>
    <p class="text-slate-400 mt-1">All tenant accounts on the platform</p>

    <div class="mt-6 overflow-x-auto rounded-xl border border-slate-800">
        <table class="w-full text-sm">
            <thead class="bg-slate-900 text-slate-400 text-left">
                <tr>
                    <th class="p-4">Organization</th>
                    <th class="p-4">Websites</th>
                    <th class="p-4">Users</th>
                    <th class="p-4">Leads</th>
                    <th class="p-4">Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach($organizations as $org)
                    <tr class="border-t border-slate-800 hover:bg-slate-900/50">
                        <td class="p-4"><a href="{{ route('admin.organizations.show', $org) }}" class="text-indigo-300 font-medium">{{ $org->name }}</a></td>
                        <td class="p-4 text-slate-400">{{ $org->websites_count }}</td>
                        <td class="p-4 text-slate-400">{{ $org->users_count }}</td>
                        <td class="p-4 text-slate-400">{{ $org->leads_count }}</td>
                        <td class="p-4"><span class="text-xs px-2 py-1 rounded {{ $org->is_active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800' }}">{{ $org->is_active ? 'Active' : 'Inactive' }}</span></td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="mt-4">{{ $organizations->links() }}</div>
</div>
@endsection
