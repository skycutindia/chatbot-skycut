<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Website;
use App\Services\WidgetConfigService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class WebsiteController extends Controller
{
    public function index(Request $request): View
    {
        $websites = Website::where('organization_id', $request->user()->organization_id)
            ->with('configuration')
            ->latest()
            ->paginate(15);

        return view('dashboard.websites.index', compact('websites'));
    }

    public function create(): View
    {
        return view('dashboard.websites.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'url' => 'nullable|url|max:2048',
        ]);

        $website = Website::create([
            'organization_id' => $request->user()->organization_id,
            'name' => $validated['name'],
            'url' => $validated['url'] ?? null,
        ]);

        if ($request->filled('domain')) {
            $website->allowedDomains()->create(['domain' => $request->string('domain')]);
        }

        return redirect()
            ->route('websites.show', $website)
            ->with('success', 'Website created. Embed snippet is ready.');
    }

    public function show(Website $website): View
    {
        $website->load(['configuration', 'allowedDomains', 'suggestedQuestions']);

        return view('dashboard.websites.show', [
            'website' => $website,
            'embedSnippet' => $website->embedSnippet(),
        ]);
    }

    public function edit(Website $website): View
    {
        $website->load(['configuration', 'allowedDomains', 'suggestedQuestions', 'operatingHours', 'qaPairs']);

        return view('dashboard.websites.edit', compact('website'));
    }

    public function update(Request $request, Website $website, WidgetConfigService $configService): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'url' => 'nullable|url|max:2048',
            'is_active' => 'boolean',
            'bot_name' => 'required|string|max:120',
            'avatar_url' => 'nullable|url|max:2048',
            'primary_color' => 'required|string|max:20',
            'secondary_color' => 'required|string|max:20',
            'theme_mode' => 'required|in:light,dark,auto',
            'position' => 'required|in:left,right',
            'locale' => 'required|string|max:10',
            'welcome_message' => 'nullable|string|max:2000',
            'typing_indicator_text' => 'nullable|string|max:120',
            'offline_message' => 'nullable|string|max:2000',
            'outside_hours_message' => 'nullable|string|max:2000',
            'ai_model' => 'required|string|max:64',
            'ai_temperature' => 'required|numeric|min:0|max:2',
            'confidence_threshold' => 'required|numeric|min:0|max:1',
            'system_prompt' => 'nullable|string|max:8000',
            'ai_enabled' => 'boolean',
            'custom_css' => 'nullable|string|max:50000',
            'custom_js' => 'nullable|string|max:50000',
            'rate_limit_per_minute' => 'required|integer|min:1|max:1000',
            'rate_limit_per_hour' => 'required|integer|min:1|max:100000',
            'require_domain_validation' => 'boolean',
            'modules' => 'nullable|array',
        ]);

        $website->update([
            'name' => $validated['name'],
            'url' => $validated['url'] ?? null,
            'is_active' => $request->boolean('is_active'),
        ]);

        $website->configuration->update([
            'bot_name' => $validated['bot_name'],
            'avatar_url' => $validated['avatar_url'] ?? null,
            'primary_color' => $validated['primary_color'],
            'secondary_color' => $validated['secondary_color'],
            'theme_mode' => $validated['theme_mode'],
            'position' => $validated['position'],
            'locale' => $validated['locale'],
            'welcome_message' => $validated['welcome_message'] ?? null,
            'typing_indicator_text' => $validated['typing_indicator_text'] ?? 'Typing...',
            'offline_message' => $validated['offline_message'] ?? null,
            'outside_hours_message' => $validated['outside_hours_message'] ?? null,
            'ai_model' => $validated['ai_model'],
            'ai_temperature' => $validated['ai_temperature'],
            'confidence_threshold' => $validated['confidence_threshold'],
            'system_prompt' => $validated['system_prompt'] ?? null,
            'ai_enabled' => $request->boolean('ai_enabled'),
            'custom_css' => $validated['custom_css'] ?? null,
            'custom_js' => $validated['custom_js'] ?? null,
            'rate_limit_per_minute' => $validated['rate_limit_per_minute'],
            'rate_limit_per_hour' => $validated['rate_limit_per_hour'],
            'require_domain_validation' => $request->boolean('require_domain_validation'),
            'enabled_modules' => $validated['modules'] ?? $website->configuration->modules(),
        ]);

        $configService->invalidate($website);

        return redirect()->route('websites.show', $website)->with('success', 'Chatbot settings saved. Changes are live instantly.');
    }

    public function destroy(Website $website, WidgetConfigService $configService): RedirectResponse
    {
        $configService->invalidate($website);
        $website->delete();

        return redirect()->route('websites.index')->with('success', 'Website removed.');
    }
}
