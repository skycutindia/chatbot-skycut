<?php

namespace App\Observers;

use App\Events\ConversationMessageSent;
use App\Models\Message;

class MessageObserver
{
    public function created(Message $message): void
    {
        if (config('broadcasting.default') !== 'null') {
            broadcast(new ConversationMessageSent($message));
        }
    }
}
