@extends('layouts.app')

@section('title', 'Knowledge - ' . $website->name)

@section('content')
<div class="max-w-5xl mx-auto">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold">Knowledge base</h1>
        <div class="flex gap-2">
            <a href="{{ route('websites.knowledge.training', $website) }}" class="text-sm px-3 py-2 rounded-lg bg-indigo-600">Train & import</a>
            <a href="{{ route('websites.show', $website) }}" class="text-sm text-indigo-400 py-2">&larr; Back</a>
        </div>
    </div>

    <div class="mt-8 grid lg:grid-cols-3 gap-8">
        <div class="lg:col-span-2 space-y-4">
            @foreach($articles as $article)
                <div class="rounded-xl bg-slate-900 border border-slate-800 p-5">
                    <div class="flex justify-between">
                        <h3 class="font-semibold">{{ $article->title }}</h3>
                        <form method="POST" action="{{ route('websites.knowledge.articles.destroy', [$website, $article]) }}">
                            @csrf @method('DELETE')
                            <button class="text-red-400 text-sm">Delete</button>
                        </form>
                    </div>
                    <p class="text-sm text-slate-400 mt-2">{{ Str::limit(strip_tags($article->content), 200) }}</p>
                </div>
            @endforeach
            {{ $articles->links() }}
        </div>

        <div class="space-y-6">
            <form method="POST" action="{{ route('websites.knowledge.articles.store', $website) }}" class="rounded-xl bg-slate-900 border border-slate-800 p-5 space-y-3">
                @csrf
                <h3 class="font-semibold">New article</h3>
                <input name="title" placeholder="Title" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
                <textarea name="content" placeholder="Content" rows="6" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm"></textarea>
                <button class="w-full py-2 rounded-lg bg-indigo-600 text-sm">Publish</button>
            </form>
            <form method="POST" action="{{ route('websites.knowledge.categories.store', $website) }}" class="rounded-xl bg-slate-900 border border-slate-800 p-5 space-y-3">
                @csrf
                <h3 class="font-semibold">New category</h3>
                <input name="name" placeholder="Category name" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
                <button class="w-full py-2 rounded-lg bg-slate-700 text-sm">Add</button>
            </form>

            <form method="POST" action="{{ route('websites.knowledge.import', $website) }}" enctype="multipart/form-data" class="rounded-xl bg-slate-900 border border-slate-800 p-5 space-y-3">
                @csrf
                <h3 class="font-semibold">Bulk import (CSV)</h3>
                <select name="import_type" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
                    <option value="qa">Q&A pairs (question, answer)</option>
                    <option value="articles">Articles (title, content)</option>
                </select>
                <input type="file" name="file" accept=".csv,.txt" required class="w-full text-sm text-slate-400">
                <button class="w-full py-2 rounded-lg bg-emerald-600 text-sm">Import</button>
            </form>
        </div>
    </div>
</div>
@endsection

