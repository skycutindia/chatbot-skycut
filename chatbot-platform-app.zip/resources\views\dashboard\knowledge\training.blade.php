@extends('layouts.app')

@section('title', 'Knowledge training')

@section('content')
<div class="max-w-5xl mx-auto">
    <div class="flex justify-between items-start">
        <div>
            <h1 class="text-3xl font-bold">Knowledge training</h1>
            <p class="text-slate-400 mt-1">{{ $website->name }} — crawl pages and upload documents</p>
        </div>
        <a href="{{ route('websites.knowledge.index', $website) }}" class="text-sm text-indigo-400">Articles →</a>
    </div>

    <div class="grid lg:grid-cols-2 gap-6 mt-8">
        <form method="POST" action="{{ route('websites.knowledge.crawl', $website) }}" class="rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            @csrf
            <h2 class="font-semibold">Website crawler</h2>
            <p class="text-sm text-slate-400">Indexes same-domain pages (max {{ config('chatbot.crawl.max_pages') }} pages, depth {{ config('chatbot.crawl.max_depth') }}).</p>
            <input name="label" placeholder="Label (optional)" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            <input type="url" name="url" value="{{ $website->url }}" placeholder="https://example.com" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            <button class="w-full py-2 rounded-lg bg-indigo-600 text-sm">Start crawl (queued)</button>
        </form>

        <form method="POST" action="{{ route('websites.knowledge.upload', $website) }}" enctype="multipart/form-data" class="rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            @csrf
            <h2 class="font-semibold">File upload</h2>
            <p class="text-sm text-slate-400">TXT, CSV, DOCX, or PDF — content is extracted and indexed as articles.</p>
            <input name="label" placeholder="Label (optional)" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            <input type="file" name="file" accept=".txt,.csv,.docx,.pdf" required class="w-full text-sm text-slate-400">
            <button class="w-full py-2 rounded-lg bg-emerald-600 text-sm">Upload & index (queued)</button>
        </form>
    </div>

    <div class="mt-10">
        <h2 class="text-lg font-semibold">Training jobs</h2>
        <div class="mt-4 space-y-2">
            @forelse($sources as $source)
                <div class="flex flex-wrap gap-4 justify-between items-center rounded-xl bg-slate-900 border border-slate-800 p-4">
                    <div>
                        <p class="font-medium">{{ $source->label ?: ucfirst($source->type) }}</p>
                        <p class="text-xs text-slate-500 mt-1">
                            {{ $source->type === 'crawl' ? $source->source_url : $source->file_name }}
                            · {{ $source->items_indexed }} indexed
                        </p>
                        @if($source->error_message)
                            <p class="text-xs text-red-400 mt-1">{{ $source->error_message }}</p>
                        @endif
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="text-xs px-2 py-1 rounded
                            @if($source->status === 'completed') bg-emerald-500/20 text-emerald-400
                            @elseif($source->status === 'failed') bg-red-500/20 text-red-400
                            @elseif($source->status === 'processing') bg-amber-500/20 text-amber-300
                            @else bg-slate-800 text-slate-400 @endif">{{ $source->status }}</span>
                        <form method="POST" action="{{ route('websites.knowledge.sources.destroy', [$website, $source]) }}">@csrf @method('DELETE')<button class="text-red-400 text-xs">Remove</button></form>
                    </div>
                </div>
            @empty
                <p class="text-slate-500 text-sm">No training jobs yet.</p>
            @endforelse
        </div>
        <div class="mt-4">{{ $sources->links() }}</div>
    </div>
</div>
@endsection
