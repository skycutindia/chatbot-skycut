@extends('layouts.app')

@section('title', 'Live Inbox')

@section('content')
@php $awaitingCount = $awaitingCount ?? 0; @endphp
<div class="max-w-6xl mx-auto">
    <div class="flex flex-wrap gap-4 justify-between items-start mb-8">
        <div>
            <h1 class="dash-page-title">Live Inbox</h1>
            <p class="dash-page-sub">Real-time agent queue — respond to visitors waiting for help</p>
        </div>
        @if($awaitingCount > 0)
            <span class="dash-badge dash-badge-warning text-sm px-4 py-2">{{ $awaitingCount }} awaiting agent</span>
        @endif
    </div>

    <form method="GET" class="dash-card p-4 mb-6 flex flex-wrap gap-3 items-center">
        <select name="status" class="dash-input rounded-xl px-4 py-2.5 text-sm">
            <option value="">Open & awaiting</option>
            <option value="awaiting_agent" @selected(request('status') === 'awaiting_agent')>Awaiting agent only</option>
            <option value="open" @selected(request('status') === 'open')>Open</option>
            <option value="closed" @selected(request('status') === 'closed')>Closed</option>
        </select>
        <button type="submit" class="dash-btn-secondary text-sm">Filter</button>
    </form>

    <div class="space-y-3" id="inbox-list">
        @forelse($conversations as $conversation)
            <div class="dash-card p-5 flex flex-wrap gap-4 justify-between items-center {{ $conversation->status === 'awaiting_agent' ? 'ring-2 ring-amber-400/50' : '' }}" data-conversation-id="{{ $conversation->id }}">
                <div class="flex items-start gap-4">
                    <div class="w-10 h-10 rounded-full bg-[var(--brand-50)] text-[var(--brand)] flex items-center justify-center font-semibold text-sm">
                        {{ strtoupper(substr($conversation->visitor_name ?: 'V', 0, 1)) }}
                    </div>
                    <div>
                        <p class="font-semibold">{{ $conversation->visitor_name ?: 'Visitor '.$conversation->visitor_id }}</p>
                        <p class="text-sm dash-muted">{{ $conversation->website?->name }} · {{ $conversation->last_message_at?->diffForHumans() }}</p>
                        <div class="flex gap-2 mt-2">
                            <span class="dash-badge {{ $conversation->status === 'awaiting_agent' ? 'dash-badge-warning' : 'dash-badge-muted' }}">{{ $conversation->status }}</span>
                            <span class="dash-badge dash-badge-muted">{{ $conversation->mode }} mode</span>
                        </div>
                    </div>
                </div>
                <div class="flex gap-2 flex-wrap">
                    <a href="{{ route('websites.conversations.show', [$conversation->website, $conversation]) }}" class="dash-btn-primary text-sm py-2">Open chat</a>
                    @if(!$conversation->assigned_user_id)
                        <form method="POST" action="{{ route('inbox.assign', $conversation) }}">@csrf<button type="submit" class="dash-btn-secondary text-sm py-2">Assign to me</button></form>
                    @endif
                    @if($conversation->status !== 'closed')
                        <form method="POST" action="{{ route('inbox.close', $conversation) }}">@csrf<button type="submit" class="text-sm text-red-500 px-3 py-2">Close</button></form>
                    @endif
                </div>
            </div>
        @empty
            <div class="dash-card p-12 text-center">
                <p class="dash-muted">No conversations in this queue.</p>
                <p class="text-sm dash-muted mt-2">Embed the widget on your site and send a message to test live handoff.</p>
            </div>
        @endforelse
    </div>
    <div class="mt-6">{{ $conversations->links() }}</div>
</div>
@endsection
