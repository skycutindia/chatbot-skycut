@extends('layouts.app')

@section('title', $website->name)

@section('content')
<div class="max-w-5xl mx-auto">
    <div class="flex flex-wrap gap-4 justify-between items-start">
        <div>
            <h1 class="text-3xl font-bold">{{ $website->name }}</h1>
            <p class="text-slate-400 mt-1">Bot token: <code class="text-indigo-300 text-sm">{{ $website->bot_token }}</code></p>
        </div>
        <div class="flex gap-2 flex-wrap">
            <a href="{{ route('websites.edit', $website) }}" class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Settings</a>
            <a href="{{ route('websites.knowledge.index', $website) }}" class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm">Knowledge</a>
            <a href="{{ route('websites.knowledge.training', $website) }}" class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm">Train</a>
            <a href="{{ route('websites.conversations.index', $website) }}" class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm">Conversations</a>
            <a href="{{ route('websites.embed', $website) }}" class="px-4 py-2 rounded-lg bg-emerald-600 text-sm">Embed code</a>
            <a href="{{ route('websites.quick-actions.index', $website) }}" class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm">Quick actions</a>
            <a href="{{ route('websites.analytics', $website) }}" class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm">Analytics</a>
        </div>
    </div>

    <div class="mt-8 rounded-2xl bg-slate-900 border border-slate-800 p-6">
        <h2 class="font-semibold text-lg">Embed snippet</h2>
        <p class="text-sm text-slate-400 mt-1">Paste before closing <code>&lt;/body&gt;</code>. All content loads dynamically from the API.</p>
        <pre class="mt-4 p-4 rounded-lg bg-slate-950 text-emerald-300 text-sm overflow-x-auto"><code>{{ $embedSnippet }}</code></pre>
    </div>

    <div class="mt-8 grid md:grid-cols-2 gap-6">
        <div class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h3 class="font-semibold">Appearance</h3>
            <ul class="mt-3 text-sm text-slate-400 space-y-1">
                <li>Bot: {{ $website->configuration->bot_name }}</li>
                <li>Theme: {{ $website->configuration->theme_mode }}</li>
                <li>Position: {{ $website->configuration->position }}</li>
                <li>Colors: {{ $website->configuration->primary_color }} / {{ $website->configuration->secondary_color }}</li>
            </ul>
        </div>
        <div class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h3 class="font-semibold">AI</h3>
            <ul class="mt-3 text-sm text-slate-400 space-y-1">
                <li>Model: {{ $website->configuration->ai_model }}</li>
                <li>Temperature: {{ $website->configuration->ai_temperature }}</li>
                <li>Confidence: {{ $website->configuration->confidence_threshold }}</li>
                <li>AI enabled: {{ $website->configuration->ai_enabled ? 'Yes' : 'No' }}</li>
            </ul>
        </div>
    </div>

    <div class="mt-8 rounded-2xl bg-slate-900 border border-slate-800 p-6">
        <h3 class="font-semibold">Suggested questions</h3>
        <ul class="mt-3 space-y-2">
            @foreach($website->suggestedQuestions as $q)
                <li class="flex justify-between text-sm">
                    <span>{{ $q->question }}</span>
                    <form method="POST" action="{{ route('websites.questions.destroy', [$website, $q]) }}">
                        @csrf @method('DELETE')
                        <button class="text-red-400 hover:text-red-300">Remove</button>
                    </form>
                </li>
            @endforeach
        </ul>
        <form method="POST" action="{{ route('websites.questions.store', $website) }}" class="mt-4 flex gap-2">
            @csrf
            <input type="text" name="question" placeholder="Add suggested question" class="flex-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            <button class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Add</button>
        </form>
    </div>
</div>
@endsection


