@extends('layouts.app')

@section('title', 'Search')

@section('content')
<div class="max-w-3xl mx-auto">
    <h1 class="text-2xl font-bold">Search</h1>
    <form method="GET" action="{{ route('search') }}" class="mt-4 flex gap-2">
        <input name="q" value="{{ $query }}" placeholder="Search..." class="dash-input flex-1 rounded-xl border px-4 py-2.5 text-sm">
        <button class="px-5 py-2.5 rounded-xl bg-indigo-600 text-sm font-medium">Search</button>
    </form>

    <ul class="mt-8 space-y-2">
        @forelse($results as $result)
            <li>
                <a href="{{ $result['url'] }}" class="dash-card block rounded-xl border p-4 hover:border-indigo-500/40 transition">
                    <p class="font-medium">{{ $result['title'] }}</p>
                    <p class="text-sm dash-muted mt-1">{{ $result['subtitle'] }} · {{ $result['type'] }}</p>
                </a>
            </li>
        @empty
            <li class="dash-muted py-8 text-center">
                @if(strlen($query) >= 2)
                    No results for “{{ $query }}”.
                @else
                    Type at least 2 characters to search.
                @endif
            </li>
        @endforelse
    </ul>
</div>
@endsection
