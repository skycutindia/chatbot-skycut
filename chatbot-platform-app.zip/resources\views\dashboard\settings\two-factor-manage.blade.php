@extends('layouts.app')

@section('title', 'Two-factor authentication')

@section('content')
<div class="max-w-2xl mx-auto">
    <h1 class="text-3xl font-bold">Two-factor authentication</h1>
    <p class="text-slate-400 mt-1">Your account is protected with an authenticator app</p>

    <div class="mt-8 space-y-6">
        <div class="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl px-6 py-4 text-emerald-300 text-sm">
            Two-factor authentication is active since {{ $user->two_factor_confirmed_at->format('M j, Y') }}.
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <h2 class="font-medium">Recovery codes</h2>
            <p class="text-sm text-slate-400 mt-1">Use recovery codes if you lose access to your authenticator app.</p>
            <a href="{{ route('settings.two-factor.recovery-codes') }}"
               class="inline-block mt-4 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm">
                View / regenerate recovery codes
            </a>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <h2 class="font-medium text-red-300">Disable two-factor authentication</h2>
            <p class="text-sm text-slate-400 mt-1">You will need your password and a current authentication code.</p>
            <form method="POST" action="{{ route('settings.two-factor.disable') }}" class="mt-4 space-y-4">
                @csrf
                @method('DELETE')
                <div>
                    <label class="block text-sm text-slate-400 mb-1">Password</label>
                    <input type="password" name="password" required
                           class="w-full max-w-sm rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                    @error('password')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label class="block text-sm text-slate-400 mb-1">Authentication code</label>
                    <input type="text" name="code" inputmode="numeric" required
                           class="w-full max-w-xs rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                    @error('code')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
                </div>
                <button type="submit" class="px-4 py-2 rounded-lg bg-red-600/80 hover:bg-red-600 text-sm font-medium">
                    Disable two-factor authentication
                </button>
            </form>
        </div>
    </div>

    <p class="mt-6 text-sm">
        <a href="{{ route('settings.profile.edit') }}" class="text-indigo-400 hover:text-indigo-300">← Back to profile</a>
    </p>
</div>
@endsection
