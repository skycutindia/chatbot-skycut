@extends('layouts.app')

@section('title', 'Organization settings')

@section('content')
<div class="max-w-2xl mx-auto">
    <h1 class="text-3xl font-bold">Organization settings</h1>
    <p class="text-slate-400 mt-1">Branding and defaults for your workspace</p>

    <form method="POST" action="{{ route('settings.organization.update') }}" class="mt-8 space-y-6 bg-slate-900 border border-slate-800 rounded-2xl p-8">
        @csrf
        @method('PUT')

        <div>
            <label class="block text-sm text-slate-400 mb-1">Organization name</label>
            <input type="text" name="name" value="{{ old('name', $organization->name) }}" required
                   class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
            @error('name')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
        </div>

        <div>
            <label class="block text-sm text-slate-400 mb-1">Logo URL</label>
            <input type="url" name="logo_url" value="{{ old('logo_url', $organization->logo_url) }}" placeholder="https://example.com/logo.png"
                   class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
            @error('logo_url')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
        </div>

        <div>
            <label class="block text-sm text-slate-400 mb-1">Timezone</label>
            <select name="timezone" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                @foreach(['UTC', 'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles', 'Europe/London', 'Europe/Paris', 'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Australia/Sydney'] as $tz)
                    <option value="{{ $tz }}" @selected(old('timezone', $organization->timezone) === $tz)>{{ $tz }}</option>
                @endforeach
            </select>
            @error('timezone')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
        </div>

        <div>
            <label class="block text-sm text-slate-400 mb-1">Notification email</label>
            <input type="email" name="notification_email" value="{{ old('notification_email', $organization->settings['notification_email'] ?? '') }}"
                   placeholder="alerts@yourcompany.com"
                   class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
            <p class="text-xs text-slate-500 mt-1">Optional. Used for handoff alerts and weekly report emails.</p>
            @error('notification_email')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
        </div>

        <button type="submit" class="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-sm font-medium">Save settings</button>
    </form>
</div>
@endsection
