/**
 * AI Chatbot Hub Pro — Widget loader (aichatbot global)
 */
(function () {
  'use strict';

  const queue = window.aichatbot && window.aichatbot.q ? window.aichatbot.q : [];
  const api = function () {
    (api.q = api.q || []).push(arguments);
  };
  api.q = queue;
  window.aichatbot = api;

  function inject(token) {
    if (document.querySelector('script[data-bot-token="' + token + '"]')) return;
    const s = document.createElement('script');
    s.src = new URL('chatbot.js', document.currentScript.src).href;
    s.setAttribute('data-bot-token', token);
    s.async = true;
    document.head.appendChild(s);
  }

  function process(args) {
    const cmd = args[0];
    if (cmd === 'init' && args[1] && args[1].website_key) {
      inject(args[1].website_key);
    }
  }

  queue.forEach(process);
  api.push = function () {
    process(arguments);
    return api.q.length;
  };
})();
