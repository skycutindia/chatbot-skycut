<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Website;
use Illuminate\View\View;

class WidgetEmbedController extends Controller
{
    public function show(Website $website): View
    {
        return view('dashboard.websites.embed', [
            'website' => $website,
            'embedSnippet' => $website->embedSnippet(),
            'simpleSnippet' => $website->simpleEmbedSnippet(),
            'wordpressSnippet' => $this->wordpressSnippet($website),
            'shopifySnippet' => $this->shopifySnippet($website),
        ]);
    }

    protected function wordpressSnippet(Website $website): string
    {
        return sprintf(
            "// Add to your theme's footer.php or use a header/footer plugin:\n%s",
            $website->embedSnippet()
        );
    }

    protected function shopifySnippet(Website $website): string
    {
        return sprintf(
            "{%% comment %%} Add to theme.liquid before </body> {%% endcomment %%}\n%s",
            $website->embedSnippet()
        );
    }
}
