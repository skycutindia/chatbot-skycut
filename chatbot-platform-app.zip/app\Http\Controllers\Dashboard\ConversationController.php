<?php

namespace App\Http\Controllers\Dashboard;

use App\Events\ConversationUpdated;
use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\ConversationNote;
use App\Models\Message;
use App\Models\Website;
use App\Services\LiveHandoffService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ConversationController extends Controller
{
    public function index(Request $request, Website $website): View
    {
        $conversations = $website->conversations()
            ->with('assignedUser')
            ->when($request->status, fn ($q, $s) => $q->where('status', $s))
            ->latest('last_message_at')
            ->paginate(25);

        return view('dashboard.conversations.index', compact('website', 'conversations'));
    }

    public function show(Website $website, Conversation $conversation): View
    {
        abort_unless($conversation->website_id === $website->id, 404);
        $conversation->load('messages');

        $canned = \App\Models\CannedResponse::query()
            ->where('organization_id', auth()->user()->organization_id)
            ->where(function ($q) use ($website) {
                $q->whereNull('website_id')->orWhere('website_id', $website->id);
            })
            ->where('is_active', true)
            ->orderBy('title')
            ->get();

        return view('dashboard.conversations.show', compact('website', 'conversation', 'canned'));
    }

    public function messages(Request $request, Website $website, Conversation $conversation): JsonResponse
    {
        abort_unless($conversation->website_id === $website->id, 404);

        $afterId = (int) $request->query('after_id', 0);

        $messages = $conversation->messages()
            ->when($afterId > 0, fn ($q) => $q->where('id', '>', $afterId))
            ->get()
            ->map(fn (Message $m) => [
                'id' => $m->id,
                'content' => $m->content,
                'sender_type' => $m->sender_type,
                'source' => $m->source,
                'created_at' => $m->created_at->toIso8601String(),
            ]);

        return response()->json([
            'messages' => $messages,
            'status' => $conversation->fresh()->status,
            'mode' => $conversation->fresh()->mode,
        ]);
    }

    public function reply(Request $request, Website $website, Conversation $conversation): RedirectResponse|JsonResponse
    {
        abort_unless($conversation->website_id === $website->id, 404);

        $validated = $request->validate(['content' => 'required|string|max:4000']);

        $message = $conversation->messages()->create([
            'sender_type' => 'agent',
            'sender_id' => $request->user()->id,
            'content' => $validated['content'],
            'source' => 'live_agent',
        ]);

        $conversation->update([
            'assigned_user_id' => $request->user()->id,
            'last_message_at' => now(),
            'status' => 'open',
            'mode' => 'human',
        ]);

        broadcast(new ConversationUpdated($conversation->fresh(), 'agent_reply'));

        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'message' => [
                    'id' => $message->id,
                    'content' => $message->content,
                    'sender_type' => $message->sender_type,
                    'source' => $message->source,
                    'created_at' => $message->created_at->toIso8601String(),
                ],
            ]);
        }

        return back()->with('success', 'Reply sent.');
    }

    public function close(Website $website, Conversation $conversation): RedirectResponse
    {
        abort_unless($conversation->website_id === $website->id, 404);
        $conversation->update(['status' => 'closed', 'closed_at' => now()]);
        broadcast(new ConversationUpdated($conversation->fresh(), 'closed'));

        return redirect()->route('websites.conversations.index', $website)->with('success', 'Conversation closed.');
    }

    public function reopen(Website $website, Conversation $conversation): RedirectResponse
    {
        abort_unless($conversation->website_id === $website->id, 404);
        $conversation->update(['status' => 'open', 'closed_at' => null]);
        broadcast(new ConversationUpdated($conversation->fresh(), 'reopened'));

        return back()->with('success', 'Conversation reopened.');
    }

    public function storeNote(Request $request, Website $website, Conversation $conversation): RedirectResponse
    {
        abort_unless($conversation->website_id === $website->id, 404);
        $validated = $request->validate(['body' => 'required|string|max:5000']);

        ConversationNote::create([
            'conversation_id' => $conversation->id,
            'user_id' => $request->user()->id,
            'body' => $validated['body'],
        ]);

        return back()->with('success', 'Internal note saved.');
    }

    public function returnToAi(Website $website, Conversation $conversation, LiveHandoffService $handoff): RedirectResponse
    {
        abort_unless($conversation->website_id === $website->id, 404);
        $handoff->returnToAi($conversation);

        return back()->with('success', 'Control returned to AI.');
    }
}
