@extends('layouts.app')

@section('title', 'Two-factor authentication')

@section('content')
<div class="max-w-2xl mx-auto">
    <h1 class="text-3xl font-bold">Two-factor authentication</h1>
    <p class="text-slate-400 mt-1">Add an extra layer of security to your account</p>

    <div class="mt-8 bg-slate-900 border border-slate-800 rounded-2xl p-8">
        <div class="flex items-start gap-4">
            <div class="w-12 h-12 rounded-xl bg-indigo-600/20 flex items-center justify-center text-indigo-400 text-xl">🔐</div>
            <div class="flex-1">
                <h2 class="font-semibold text-lg">Authenticator app</h2>
                <p class="text-sm text-slate-400 mt-1">
                    Use Google Authenticator, Authy, 1Password, or any TOTP-compatible app.
                </p>
                @if($user->hasTwoFactorEnabled())
                    <p class="mt-3 text-sm text-emerald-400">Two-factor authentication is enabled.</p>
                @else
                    <form method="POST" action="{{ route('settings.two-factor.enable') }}" class="mt-4 space-y-3">
                        @csrf
                        <div>
                            <label class="block text-sm text-slate-400 mb-1">Confirm your password to continue</label>
                            <input type="password" name="password" required
                                   class="w-full max-w-xs rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                            @error('password')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
                        </div>
                        <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-sm font-medium">
                            Enable two-factor authentication
                        </button>
                    </form>
                @endif
            </div>
        </div>
    </div>

    <p class="mt-4 text-sm">
        <a href="{{ route('settings.profile.edit') }}" class="text-indigo-400 hover:text-indigo-300">← Back to profile</a>
    </p>
</div>
@endsection
