(function () {
    'use strict';

    initSessionSecurity();
    initThemeToggle();

    function initThemeToggle() {
        const root = document.documentElement;
        const storageKey = 'dashboard-theme';
        const toggle = document.getElementById('theme-toggle');
        const iconLight = document.querySelector('.dash-theme-icon-light');
        const iconDark = document.querySelector('.dash-theme-icon-dark');

        function applyTheme(theme) {
            root.setAttribute('data-theme', theme);
            localStorage.setItem(storageKey, theme);
            const isDark = theme === 'dark';
            iconLight?.classList.toggle('hidden', isDark);
            iconDark?.classList.toggle('hidden', !isDark);
        }

        applyTheme(root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light');

        toggle?.addEventListener('click', () => {
            applyTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
        });
    }

    function initSessionSecurity() {
        if (!document.body.classList.contains('dash-body')) {
            return;
        }

        const sessionExpiredUrl = document.querySelector('meta[name="session-expired-url"]')?.content;
        const beaconUrl = document.querySelector('meta[name="logout-beacon-url"]')?.content;
        const csrf = document.querySelector('meta[name="csrf-token"]')?.content;
        const nav = performance.getEntriesByType('navigation')[0];

        if (nav?.type === 'reload' && sessionExpiredUrl) {
            window.location.replace(sessionExpiredUrl);
            return;
        }

        let internalNav = false;

        document.querySelectorAll('a[href]').forEach((link) => {
            try {
                const url = new URL(link.href, window.location.origin);
                if (url.origin === window.location.origin) {
                    link.addEventListener('click', () => {
                        internalNav = true;
                    });
                }
            } catch (_) {}
        });

        document.querySelectorAll('form').forEach((form) => {
            form.addEventListener('submit', () => {
                internalNav = true;
            });
        });

        window.addEventListener('pagehide', () => {
            if (internalNav || !beaconUrl || !csrf) {
                return;
            }

            const data = new FormData();
            data.append('_token', csrf);
            navigator.sendBeacon(beaconUrl, data);
        });
    }

    const userBtn = document.getElementById('user-menu-button');
    const userMenu = document.getElementById('user-menu');
    userBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        userMenu?.classList.toggle('hidden');
    });
    document.addEventListener('click', () => userMenu?.classList.add('hidden'));

    const searchInput = document.getElementById('global-search');
    const searchResults = document.getElementById('search-results');
    let searchTimer = null;

    function hideSearchResults() {
        searchResults?.classList.add('hidden');
    }

    searchInput?.addEventListener('input', () => {
        clearTimeout(searchTimer);
        const q = searchInput.value.trim();
        if (q.length < 2) {
            hideSearchResults();
            return;
        }
        searchTimer = setTimeout(async () => {
            try {
                const res = await fetch('/search?q=' + encodeURIComponent(q), {
                    headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                });
                if (!res.ok) return;
                const data = await res.json();
                if (!searchResults) return;
                if (!data.results?.length) {
                    searchResults.innerHTML = '<p class="px-4 py-3 text-sm dash-muted">No results</p>';
                } else {
                    searchResults.innerHTML = data.results
                        .map(
                            (r) =>
                                `<a href="${r.url}" class="block px-4 py-3 border-b border-[var(--dash-border)] last:border-0 hover:bg-[var(--dash-hover)]">
                                    <p class="text-sm font-medium">${escapeHtml(r.title)}</p>
                                    <p class="text-xs dash-muted">${escapeHtml(r.subtitle)} · ${escapeHtml(r.type)}</p>
                                </a>`
                        )
                        .join('');
                }
                searchResults.classList.remove('hidden');
            } catch (_) {}
        }, 250);
    });

    searchInput?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            const q = searchInput.value.trim();
            if (q) window.location.href = '/search?q=' + encodeURIComponent(q);
        }
        if (e.key === 'Escape') hideSearchResults();
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('#global-search-wrap')) hideSearchResults();
    });

    function escapeHtml(text) {
        const d = document.createElement('div');
        d.textContent = text || '';
        return d.innerHTML;
    }

    const replyForm = document.getElementById('reply-form');
    replyForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const input = document.getElementById('reply-input');
        const content = input?.value.trim();
        if (!content) return;

        const btn = replyForm.querySelector('button[type="submit"]');
        if (btn) btn.disabled = true;

        try {
            const res = await fetch(replyForm.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || '',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                body: JSON.stringify({ content }),
            });

            if (!res.ok) throw new Error('Failed');

            const data = await res.json();
            appendAgentMessage(data.message);
            if (input) input.value = '';
        } catch (_) {
            replyForm.submit();
        } finally {
            if (btn) btn.disabled = false;
        }
    });

    function appendAgentMessage(message) {
        const list = document.getElementById('message-list');
        if (!list || !message || document.querySelector(`[data-msg-id="${message.id}"]`)) return;

        const wrap = document.createElement('div');
        wrap.dataset.msgId = message.id;
        wrap.className = 'flex justify-start';
        wrap.innerHTML = `
            <div class="max-w-[80%] rounded-2xl px-4 py-3 text-sm bg-slate-800 border border-slate-700">
                ${escapeHtml(message.content)}
                <p class="text-xs opacity-60 mt-1">just now · ${escapeHtml(message.source)}</p>
            </div>`;
        list.appendChild(wrap);
        list.scrollTop = list.scrollHeight;
    }

    const realtime = window.__CHATBOT_REALTIME__;
    if (realtime?.page === 'conversation' && realtime.messagesUrl && realtime.conversationId) {
        let lastMessageId = 0;
        document.querySelectorAll('[data-msg-id]').forEach((el) => {
            const id = parseInt(el.dataset.msgId, 10);
            if (id > lastMessageId) lastMessageId = id;
        });

        setInterval(async () => {
            try {
                const res = await fetch(`${realtime.messagesUrl}?after_id=${lastMessageId}`, {
                    headers: { Accept: 'application/json' },
                });
                if (!res.ok) return;
                const data = await res.json();
                data.messages?.forEach((message) => {
                    if (message.sender_type === 'visitor') {
                        const list = document.getElementById('message-list');
                        if (!list || document.querySelector(`[data-msg-id="${message.id}"]`)) return;
                        const wrap = document.createElement('div');
                        wrap.dataset.msgId = message.id;
                        wrap.className = 'flex justify-end';
                        wrap.innerHTML = `
                            <div class="max-w-[80%] rounded-2xl px-4 py-3 text-sm bg-indigo-600">
                                ${escapeHtml(message.content)}
                                <p class="text-xs opacity-60 mt-1">${escapeHtml(message.source)}</p>
                            </div>`;
                        list.appendChild(wrap);
                        list.scrollTop = list.scrollHeight;
                    }
                    if (message.id > lastMessageId) lastMessageId = message.id;
                });
                const statusEl = document.getElementById('conv-status');
                if (statusEl && data.status) statusEl.textContent = data.status;
            } catch (_) {}
        }, 1500);
    }
})();
