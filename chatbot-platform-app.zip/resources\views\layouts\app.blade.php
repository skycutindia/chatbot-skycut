﻿<!DOCTYPE html>
<html lang="en" class="dash-layout">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="session-expired-url" content="{{ route('auth.session-expired') }}">
    <meta name="logout-beacon-url" content="{{ route('auth.logout-beacon') }}">
    <title>@yield('title', 'Dashboard') — SkyCut</title>
    <script>
        (function () {
            var theme = localStorage.getItem('dashboard-theme') || 'light';
            document.documentElement.setAttribute('data-theme', theme);
        })();
    </script>
    <link rel="stylesheet" href="{{ asset('css/dashboard-theme.css') }}">
    @if (file_exists(public_path('build/manifest.json')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @endif
    @auth
        @if(auth()->user()->organization_id)
            @php
                $realtimePage = request()->routeIs('inbox.*') ? 'inbox' : (request()->routeIs('websites.conversations.show') ? 'conversation' : (request()->routeIs('websites.hub') ? 'hub' : null));
                $realtimeConversationId = request()->route('conversation')?->id;
                $realtimeMessagesUrl = request()->routeIs('websites.conversations.show')
                    ? route('websites.conversations.messages', [request()->route('website'), request()->route('conversation')])
                    : null;
            @endphp
            <script>
                window.__CHATBOT_REALTIME__ = {
                    orgId: {{ auth()->user()->organization_id }},
                    page: @json($realtimePage),
                    conversationId: @json($realtimeConversationId),
                    messagesUrl: @json($realtimeMessagesUrl),
                };
            </script>
            @if (file_exists(public_path('build/manifest.json')))
                @vite(['resources/js/realtime.js'])
            @endif
        @endif
    @endauth
</head>
<body class="dash-body">
<div class="dash-shell">
    <div id="dash-sidebar-backdrop" class="dash-sidebar-backdrop" aria-hidden="true"></div>
    @include('layouts.partials.sidebar')

    <div class="dash-shell-main">
        @include('layouts.partials.topbar')

        <main class="dash-shell-content dash-main" id="dash-main-scroll">
            @if(session('success'))
                <div class="mb-6 dash-alert-success">{{ session('success') }}</div>
            @endif
            @yield('content')
        </main>
    </div>
</div>
<script src="{{ asset('js/dashboard-ui.js') }}"></script>
<script>
    (function () {
        const toggle = document.getElementById('mobile-nav-toggle');
        const sidebar = document.getElementById('dash-sidebar');
        const backdrop = document.getElementById('dash-sidebar-backdrop');

        function closeSidebar() {
            sidebar?.classList.remove('dash-sidebar-open');
            backdrop?.classList.remove('dash-sidebar-backdrop-visible');
        }

        toggle?.addEventListener('click', () => {
            const open = sidebar?.classList.toggle('dash-sidebar-open');
            backdrop?.classList.toggle('dash-sidebar-backdrop-visible', open);
        });

        backdrop?.addEventListener('click', closeSidebar);
    })();
</script>
</body>
</html>
