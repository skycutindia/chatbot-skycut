<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class OrganizationSettingsController extends Controller
{
    public function edit(Request $request): View
    {
        $organization = $request->user()->organization;

        abort_unless($organization, 404);

        return view('dashboard.settings.organization', compact('organization'));
    }

    public function update(Request $request): RedirectResponse
    {
        $organization = $request->user()->organization;

        abort_unless($organization, 404);

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'logo_url' => 'nullable|url|max:2048',
            'timezone' => 'required|string|max:64',
            'notification_email' => 'nullable|email|max:255',
        ]);

        $settings = $organization->settings ?? [];
        $settings['notification_email'] = $validated['notification_email'] ?? null;

        $organization->update([
            'name' => $validated['name'],
            'logo_url' => $validated['logo_url'] ?? null,
            'timezone' => $validated['timezone'],
            'settings' => $settings,
        ]);

        return back()->with('success', 'Organization settings saved.');
    }
}
