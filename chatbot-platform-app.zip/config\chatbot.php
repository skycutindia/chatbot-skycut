<?php

return [
    'openai' => [
        'api_key' => env('OPENAI_API_KEY'),
        'base_url' => env('OPENAI_BASE_URL', 'https://api.openai.com/v1'),
    ],

    'widget' => [
        'cache_ttl' => (int) env('WIDGET_CONFIG_CACHE_TTL', 60),
        'cors_max_age' => 86400,
    ],

    'lockout_attempts' => (int) env('AUTH_LOCKOUT_ATTEMPTS', 5),
    'lockout_minutes' => (int) env('AUTH_LOCKOUT_MINUTES', 30),
    'sla_minutes' => (int) env('CHAT_SLA_MINUTES', 15),

    'crawl' => [
        'max_pages' => (int) env('CRAWL_MAX_PAGES', 30),
        'max_depth' => (int) env('CRAWL_MAX_DEPTH', 2),
        'timeout' => (int) env('CRAWL_TIMEOUT', 15),
    ],

    'default_handoff_triggers' => [
        'keywords' => ['human', 'agent', 'live chat', 'speak to someone', 'real person', 'representative'],
    ],

    'default_system_prompt' => 'You are a helpful customer support assistant for AI Chatbot Hub Pro. Answer based on the knowledge base when possible. Be concise, friendly, and professional. If you cannot help, suggest connecting with a live agent.',

    'semantic_search' => [
        'enabled' => (bool) env('SEMANTIC_SEARCH_ENABLED', false),
        'model' => env('OPENAI_EMBEDDING_MODEL', 'text-embedding-3-small'),
        'min_score' => (float) env('SEMANTIC_SEARCH_MIN_SCORE', 0.72),
    ],

    'social' => [
        'providers' => ['google', 'github'],
    ],

    'demo_website_slug' => env('DEMO_WEBSITE_SLUG', 'skycut'),
];
