<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class QuickAction extends Model
{
    protected $fillable = [
        'website_id', 'label', 'icon', 'action_type', 'action_value',
        'display_rules', 'sort_order', 'is_active',
    ];

    protected function casts(): array
    {
        return [
            'display_rules' => 'array',
            'is_active' => 'boolean',
        ];
    }

    public function website(): BelongsTo
    {
        return $this->belongsTo(Website::class);
    }
}
