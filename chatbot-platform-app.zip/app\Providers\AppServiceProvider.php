<?php

namespace App\Providers;

use App\Models\Message;
use App\Observers\MessageObserver;
use App\Events\ConversationAwaitingAgent;
use App\Listeners\SendHandoffNotification;
use App\View\Composers\DashboardComposer;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Message::observe(MessageObserver::class);

        Event::listen(Registered::class, SendEmailVerificationNotification::class);
        Event::listen(ConversationAwaitingAgent::class, SendHandoffNotification::class);

        View::composer(['layouts.app', 'dashboard.*'], DashboardComposer::class);
    }
}
