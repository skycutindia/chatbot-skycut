@extends('layouts.app')

@section('title', 'Edit '.$member->name)

@section('content')
<div class="max-w-lg mx-auto">
    <a href="{{ route('team.index') }}" class="text-sm text-indigo-400">← Team</a>
    <h1 class="text-2xl font-bold mt-4">Edit {{ $member->name }}</h1>
    <form method="POST" action="{{ route('team.update', $member) }}" class="mt-6 space-y-4 rounded-xl bg-slate-900 border border-slate-800 p-6">
        @csrf @method('PATCH')
        <input name="name" value="{{ $member->name }}" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <input type="email" name="email" value="{{ $member->email }}" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <select name="role" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            @foreach($roles as $role)
                <option value="{{ $role }}" @selected($member->role === $role)>{{ \App\Enums\UserRole::from($role)->label() }}</option>
            @endforeach
        </select>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" @checked($member->is_active)> Active</label>
        <input type="password" name="password" placeholder="New password (optional)" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <input type="password" name="password_confirmation" placeholder="Confirm new password" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <button class="w-full py-2 rounded-lg bg-indigo-600 text-sm font-medium">Save changes</button>
    </form>
</div>
@endsection
