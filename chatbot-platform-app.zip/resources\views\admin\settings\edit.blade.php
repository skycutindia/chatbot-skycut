@extends('layouts.app')

@section('title', 'Platform Settings')

@section('content')
<div class="max-w-2xl mx-auto">
    <a href="{{ route('dashboard') }}" class="text-sm text-indigo-400">← Dashboard</a>
    <h1 class="text-3xl font-bold mt-4">Platform Settings</h1>
    <p class="text-slate-400 mt-1">Global AI and system configuration</p>

    <form method="POST" action="{{ route('admin.settings.update') }}" class="mt-8 rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4">
        @csrf @method('PUT')
        <div>
            <label class="text-sm text-slate-400">Platform name</label>
            <input name="platform_name" value="{{ old('platform_name', $platformName) }}" class="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        </div>
        <div>
            <label class="text-sm text-slate-400">OpenAI API key</label>
            <input type="password" name="openai_api_key" placeholder="Leave blank to keep current" class="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            <p class="text-xs text-slate-500 mt-1">Overrides .env when set. Used as fallback for all tenants.</p>
        </div>
        <div>
            <label class="text-sm text-slate-400">Default OpenAI model</label>
            <input name="openai_default_model" value="{{ old('openai_default_model', $openaiModel) }}" class="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        </div>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="maintenance_mode" value="1" @checked($maintenanceMode)> Maintenance mode</label>
        <button class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Save settings</button>
    </form>
</div>
@endsection
