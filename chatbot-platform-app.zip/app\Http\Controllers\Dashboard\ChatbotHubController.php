<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Lead;
use App\Models\Website;
use App\Services\AnalyticsService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ChatbotHubController extends Controller
{
    public function show(Request $request, Website $website, AnalyticsService $analytics): View
    {
        abort_unless($website->organization_id === $request->user()->organization_id
            || $request->user()->roleEnum()->isPlatformLevel(), 403);

        $website->load(['configuration', 'suggestedQuestions', 'quickActions']);

        $days = 30;
        $summary = $analytics->summary($website, $days);

        $recentConversations = $website->conversations()
            ->withCount('messages')
            ->latest('last_message_at')
            ->limit(5)
            ->get();

        $stats = [
            'open_chats' => $website->conversations()->whereIn('status', ['open', 'awaiting_agent'])->count(),
            'total_conversations' => $summary['conversations'],
            'leads' => Lead::where('website_id', $website->id)->count(),
            'messages' => $summary['messages'],
            'handoff_rate' => $summary['handoff_rate'],
            'avg_satisfaction' => $summary['avg_satisfaction'],
        ];

        return view('dashboard.websites.hub', [
            'website' => $website,
            'stats' => $stats,
            'summary' => $summary,
            'recentConversations' => $recentConversations,
            'days' => $days,
            'embedSnippet' => $website->embedSnippet(),
        ]);
    }
}
