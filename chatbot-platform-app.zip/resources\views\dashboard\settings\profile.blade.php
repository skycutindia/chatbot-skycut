@extends('layouts.app')

@section('title', 'My profile')

@section('content')
<div class="max-w-2xl mx-auto">
    <h1 class="text-3xl font-bold">My profile</h1>
    <p class="text-slate-400 mt-1">Update your account details and password</p>

    @if(!$user->hasVerifiedEmail())
        <div class="mt-6 rounded-lg bg-amber-500/10 border border-amber-500/30 px-4 py-3 text-amber-200 text-sm">
            Your email is not verified.
            <a href="{{ route('verification.notice') }}" class="underline ml-1">Verify now</a>
        </div>
    @endif

    <form method="POST" action="{{ route('settings.profile.update') }}" class="mt-8 space-y-6 bg-slate-900 border border-slate-800 rounded-2xl p-8">
        @csrf
        @method('PUT')

        <div>
            <label class="block text-sm text-slate-400 mb-1">Name</label>
            <input type="text" name="name" value="{{ old('name', $user->name) }}" required
                   class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
            @error('name')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
        </div>

        <div>
            <label class="block text-sm text-slate-400 mb-1">Email</label>
            <input type="email" name="email" value="{{ old('email', $user->email) }}" required
                   class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
            @error('email')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
        </div>

        <div class="pt-4 border-t border-slate-800">
            <p class="text-sm font-medium text-slate-300 mb-4">Change password</p>
            <div class="space-y-4">
                <div>
                    <label class="block text-sm text-slate-400 mb-1">Current password</label>
                    <input type="password" name="current_password"
                           class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                    @error('current_password')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label class="block text-sm text-slate-400 mb-1">New password</label>
                    <input type="password" name="password"
                           class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                    @error('password')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label class="block text-sm text-slate-400 mb-1">Confirm new password</label>
                    <input type="password" name="password_confirmation"
                           class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                </div>
            </div>
        </div>

        <button type="submit" class="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-sm font-medium">Save profile</button>
    </form>

    <div class="mt-8 bg-slate-900 border border-slate-800 rounded-2xl p-8">
        <h2 class="font-medium text-lg">Connected accounts</h2>
        @if($user->socialAccounts->isEmpty())
            <p class="text-sm text-slate-400 mt-1">No social accounts linked. Connect Google or GitHub from the sign-in page.</p>
        @else
            <ul class="mt-4 space-y-2">
                @foreach($user->socialAccounts as $account)
                    <li class="flex items-center gap-3 text-sm">
                        <span class="px-2 py-1 rounded bg-slate-800 capitalize">{{ $account->provider }}</span>
                        <span class="text-slate-400">{{ $account->provider_email ?? 'Linked' }}</span>
                    </li>
                @endforeach
            </ul>
        @endif
    </div>

    <div class="mt-8 bg-slate-900 border border-slate-800 rounded-2xl p-8">
        <h2 class="font-medium text-lg">Two-factor authentication</h2>
        <p class="text-sm text-slate-400 mt-1">
            @if($user->hasTwoFactorEnabled())
                Enabled — your account requires a code from your authenticator app when signing in.
            @else
                Not enabled — protect your account with an authenticator app.
            @endif
        </p>
        <a href="{{ route('settings.two-factor.show') }}"
           class="inline-block mt-4 px-4 py-2 rounded-lg {{ $user->hasTwoFactorEnabled() ? 'bg-slate-800 hover:bg-slate-700' : 'bg-indigo-600 hover:bg-indigo-500' }} text-sm font-medium">
            {{ $user->hasTwoFactorEnabled() ? 'Manage two-factor authentication' : 'Enable two-factor authentication' }}
        </a>
    </div>
</div>
@endsection
