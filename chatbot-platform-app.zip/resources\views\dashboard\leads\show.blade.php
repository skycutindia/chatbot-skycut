@extends('layouts.app')

@section('title', 'Lead #'.$lead->id)

@section('content')
<div class="max-w-5xl mx-auto">
    <a href="{{ route('leads.index') }}" class="text-sm text-indigo-400">← Back to leads</a>
    <h1 class="text-3xl font-bold mt-4">{{ $lead->name ?: 'Lead #'.$lead->id }}</h1>
    <p class="text-slate-400">{{ $lead->email }} · {{ $lead->phone }}</p>

    <div class="grid md:grid-cols-2 gap-6 mt-8">
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold">Details</h2>
            <dl class="mt-4 space-y-2 text-sm">
                <div class="flex justify-between"><dt class="text-slate-500">Company</dt><dd>{{ $lead->company ?: '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-500">Website</dt><dd>{{ $lead->website?->name }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-500">Source</dt><dd class="truncate max-w-xs">{{ $lead->source_url ?: '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-500">IP</dt><dd>{{ $lead->ip_address ?: '—' }}</dd></div>
            </dl>
            <form method="POST" action="{{ route('leads.update', $lead) }}" class="mt-6 space-y-3">
                @csrf @method('PATCH')
                <label class="block text-sm text-slate-400">Pipeline status</label>
                <select name="status" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
                    @foreach(\App\Enums\LeadStatus::cases() as $status)
                        <option value="{{ $status->value }}" @selected($lead->status === $status->value)>{{ $status->label() }}</option>
                    @endforeach
                </select>
                <button class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Update</button>
            </form>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold">Notes</h2>
            <div class="mt-4 space-y-3 max-h-64 overflow-y-auto">
                @foreach($lead->notes as $note)
                    <div class="text-sm border-l-2 border-indigo-500 pl-3">
                        <p class="text-slate-300">{{ $note->body }}</p>
                        <p class="text-xs text-slate-500 mt-1">{{ $note->user?->name }} · {{ $note->created_at?->diffForHumans() }}</p>
                    </div>
                @endforeach
            </div>
            <form method="POST" action="{{ route('leads.notes.store', $lead) }}" class="mt-4 flex gap-2">
                @csrf
                <input type="text" name="body" placeholder="Add note..." class="flex-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm" required>
                <button class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Add</button>
            </form>
        </div>
    </div>

    @if($lead->chat_transcript)
        <div class="mt-8 rounded-xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold">Chat transcript</h2>
            <pre class="mt-4 text-xs text-slate-400 whitespace-pre-wrap max-h-96 overflow-y-auto">{{ $lead->chat_transcript }}</pre>
        </div>
    @endif
</div>
@endsection
