@extends('layouts.app')

@section('title', $website->name.' — Chatbot Hub')

@section('content')
<div class="max-w-6xl mx-auto">
    <div class="flex flex-wrap gap-4 justify-between items-start">
        <div>
            <p class="text-sm text-indigo-400 font-medium">Chatbot dashboard</p>
            <h1 class="text-3xl font-bold mt-1">{{ $website->name }}</h1>
            <p class="text-slate-400 mt-1">{{ $website->configuration->bot_name }} · Last {{ $days }} days</p>
        </div>
        <div class="flex flex-wrap gap-2">
            <a href="{{ route('websites.edit', $website) }}" class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm">Settings</a>
        </div>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-5">
            <p class="text-slate-400 text-sm">Open chats</p>
            <p class="text-2xl font-bold mt-1">{{ $stats['open_chats'] }}</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-5">
            <p class="text-slate-400 text-sm">Conversations</p>
            <p class="text-2xl font-bold mt-1">{{ $stats['total_conversations'] }}</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-5">
            <p class="text-slate-400 text-sm">Leads</p>
            <p class="text-2xl font-bold mt-1">{{ $stats['leads'] }}</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-5">
            <p class="text-slate-400 text-sm">Handoff rate</p>
            <p class="text-2xl font-bold mt-1">{{ $stats['handoff_rate'] }}%</p>
        </div>
    </div>

    <div class="mt-10 grid lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 space-y-6">
            <div class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
                <h2 class="font-semibold text-lg">Quick actions</h2>
                <div class="mt-4 grid sm:grid-cols-2 gap-3">
                    <a href="{{ route('inbox.index') }}" class="rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 p-4">
                        <p class="font-medium">Live Inbox</p>
                        <p class="text-xs text-slate-500 mt-1">Answer waiting visitors</p>
                    </a>
                    <a href="{{ route('websites.conversations.index', $website) }}" class="rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 p-4">
                        <p class="font-medium">All conversations</p>
                        <p class="text-xs text-slate-500 mt-1">History & agent replies</p>
                    </a>
                    <a href="{{ route('websites.knowledge.index', $website) }}" class="rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 p-4">
                        <p class="font-medium">Knowledge base</p>
                        <p class="text-xs text-slate-500 mt-1">FAQ articles & categories</p>
                    </a>
                    <a href="{{ route('websites.knowledge.training', $website) }}" class="rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 p-4">
                        <p class="font-medium">Train bot</p>
                        <p class="text-xs text-slate-500 mt-1">Upload docs & crawl pages</p>
                    </a>
                    <a href="{{ route('websites.analytics', $website) }}" class="rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 p-4">
                        <p class="font-medium">Analytics</p>
                        <p class="text-xs text-slate-500 mt-1">Handoff & satisfaction</p>
                    </a>
                    <a href="{{ route('websites.embed', $website) }}" class="rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 p-4">
                        <p class="font-medium">Embed widget</p>
                        <p class="text-xs text-slate-500 mt-1">Copy install snippet</p>
                    </a>
                </div>
            </div>

            <div class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
                <div class="flex justify-between items-center">
                    <h2 class="font-semibold text-lg">Recent conversations</h2>
                    <a href="{{ route('websites.conversations.index', $website) }}" class="text-sm text-indigo-400">View all</a>
                </div>
                <ul class="mt-4 space-y-2">
                    @forelse($recentConversations as $conversation)
                        <li>
                            <a href="{{ route('websites.conversations.show', [$website, $conversation]) }}"
                               class="flex justify-between items-center rounded-lg bg-slate-800/50 px-4 py-3 hover:bg-slate-800 text-sm">
                                <span>{{ $conversation->visitor_name ?: 'Visitor #'.$conversation->id }}</span>
                                <span class="text-xs text-slate-500">{{ $conversation->messages_count }} msgs · {{ $conversation->status }}</span>
                            </a>
                        </li>
                    @empty
                        <li class="text-slate-500 text-sm">No conversations yet — embed the widget to start receiving chats.</li>
                    @endforelse
                </ul>
            </div>
        </div>

        <div class="space-y-6">
            <div class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
                <h2 class="font-semibold">Bot preview</h2>
                <ul class="mt-3 text-sm text-slate-400 space-y-2">
                    <li><span class="text-slate-500">Name:</span> {{ $website->configuration->bot_name }}</li>
                    <li><span class="text-slate-500">Welcome:</span> {{ Str::limit($website->configuration->welcome_message, 80) }}</li>
                    <li><span class="text-slate-500">AI:</span> {{ $website->configuration->ai_enabled ? 'Enabled' : 'Off' }}</li>
                </ul>
            </div>

            <div class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
                <h2 class="font-semibold text-sm">Embed snippet</h2>
                <pre class="mt-3 p-3 rounded-lg bg-slate-950 text-emerald-300 text-xs overflow-x-auto max-h-40"><code>{{ $embedSnippet }}</code></pre>
            </div>
        </div>
    </div>
</div>
@endsection
