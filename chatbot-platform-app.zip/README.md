# AI Chatbot Hub Pro

Production-ready **Dynamic AI Chatbot Management System** — a centralized SaaS platform to create, train, deploy, and manage AI chatbots across unlimited websites from a single dashboard.

Built with **Laravel 13**, **PHP 8.3+**, **MySQL 8**, **Redis-ready** queues/cache, **REST API**, **multi-tenant architecture**, and **role-based access control**.

---

## Features

| Module | Status |
|--------|--------|
| Multi-tenant organizations | ✅ |
| Unlimited websites per tenant | ✅ |
| Dynamic chatbot configuration (API-driven widget) | ✅ |
| OpenAI integration (Q&A → KB → AI fallback) | ✅ |
| Live agent handoff & persistent conversations | ✅ |
| Lead capture & CRM pipeline | ✅ |
| Quick actions (Quote, Demo, WhatsApp, etc.) | ✅ |
| Agent live inbox | ✅ |
| Analytics events | ✅ |
| Widget embed center (HTML, WordPress, Shopify) | ✅ |
| RBAC (Super Admin, Owner, Admin, Manager, Agent, Viewer) | ✅ |
| Registration, login, forgot password, account lockout | ✅ |
| Team & role management | ✅ |
| Canned agent responses | ✅ |
| Super Admin platform panel | ✅ |
| Knowledge CSV import | ✅ |
| Website crawler (queued) | ✅ |
| File upload training (TXT/CSV/DOCX/PDF) | ✅ |
| OpenAI semantic knowledge search | ✅ |
| Handoff email notifications | ✅ |
| Password reset flow | ✅ |
| Reports & CSV export | ✅ |
| Reports Excel & PDF export | ✅ |
| Scheduled weekly email reports (CSV/Excel/PDF) | ✅ |
| Visitor satisfaction ratings | ✅ |
| Live message polling (widget + agent) | ✅ |
| Laravel Reverb WebSockets (real-time inbox) | ✅ |
| Organization settings & profile | ✅ |
| Email verification on registration | ✅ |
| Two-factor authentication (TOTP) | ✅ |
| Social login (Google, GitHub) | ✅ |
| Enhanced analytics (handoff, AI rate) | ✅ |

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    AI Chatbot Hub Pro                        │
├──────────────┬──────────────┬──────────────┬────────────────┤
│ Super Admin  │ Tenant Admin │   Manager    │ Agent / Viewer │
│  (platform)  │  (company)   │  (limited)   │  (inbox/RO)    │
└──────┬───────┴──────┬───────┴──────┬───────┴────────┬───────┘
       │              │              │                │
       ▼              ▼              ▼                ▼
┌─────────────────────────────────────────────────────────────┐
│ Organizations → Websites → Chatbot Config + Knowledge Base   │
└────────────────────────────┬────────────────────────────────┘
                             │
         ┌───────────────────┼───────────────────┐
         ▼                   ▼                   ▼
   Widget API           Dashboard            Queue Workers
   (public REST)        (Blade + Tailwind)   (async jobs)
         │
         ▼
   Embeddable JS Widget → Visitor chats → AI / Live Agent
                             │
                             ▼
                      Leads + Analytics
```

### Chat response pipeline

1. **Q&A pairs** (keyword + question variations)
2. **Trigger keywords**
3. **Knowledge base** (semantic search when enabled, else MySQL full-text search)
4. **OpenAI** (with context from KB)
5. **Live handoff** when confidence is low or visitor requests an agent

Conversations remain **open** until an agent manually closes them.

---

## Requirements

- PHP 8.3+
- Composer 2.x
- MySQL 8+ (or MariaDB with full-text support)
- Redis (recommended for cache, queues, rate limits)
- Node.js 20+ (Vite assets)
- OpenAI API key (optional for AI replies)

---

## Quick start

```bash
composer install
cp .env.example .env
php artisan key:generate

# Configure .env: DB_*, REDIS_*, OPENAI_API_KEY, APP_URL

php artisan migrate --seed
npm install && npm run build
php artisan serve
```

### MySQL

The app targets **MySQL 8** by default (`DB_CONNECTION=mysql` in `.env.example`). Create an empty database, then migrate:

```sql
CREATE DATABASE chatbot_hub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=chatbot_hub
DB_USERNAME=root
DB_PASSWORD=
```

**Docker (optional)** — with Docker Desktop installed:

```bash
docker compose up -d mysql
```

Use `DB_PASSWORD=secret` to match the compose file’s default `MYSQL_ROOT_PASSWORD`, or set `MYSQL_ROOT_PASSWORD` in your shell environment and use the same value in `DB_PASSWORD`.

**One-command setup** (after `DB_PASSWORD` is correct):

```powershell
$env:PHPRC = "e:\website\chatbot-platform\app\php-cli.ini"   # Windows: enable pdo_mysql
php artisan db:setup-mysql --seed
```

**Interactive setup** (prompts for MySQL root password and updates `.env`):

```powershell
.\scripts\setup-mysql.ps1
```

This creates `chatbot_hub` if missing, runs migrations, and seeds demo accounts.

**Moving from SQLite:** data in `database/database.sqlite` is not copied automatically. After MySQL is working, run `php artisan db:setup-mysql --seed` for a fresh demo dataset, or export/import manually.

**SQLite (local file):** set `DB_CONNECTION=sqlite`. Optionally set `DB_DATABASE` to the full path of your `.sqlite` file; otherwise Laravel uses `database/database.sqlite`.

**Demo accounts** (after seeding):

| Role | Email | Password |
|------|-------|----------|
| Super Admin | super@aichatbothub.local | password |
| Owner | admin@aichatbothub.local | password |
| Agent | agent@aichatbothub.local | password |

---

## Widget embed

```html
<script>
(function(w,d,s,o,f,js,fjs){
  w['AIChatbotWidget']=o;
  w[o]=w[o]||function(){(w[o].q=w[o].q||[]).push(arguments)};
  js=d.createElement(s),fjs=d.getElementsByTagName(s)[0];
  js.src=f; js.async=1;
  fjs.parentNode.insertBefore(js,fjs);
})(window,document,'script','aichatbot','https://YOUR-DOMAIN/widget/loader.js');
aichatbot('init',{ website_key:'YOUR_BOT_TOKEN' });
</script>
```

Or use the simple script tag from **Websites → Embed code** in the dashboard.

Preview locally: open `public/preview.html` with your bot token.

---

## API (Widget)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/widget/{botToken}/config` | Dynamic widget configuration |
| POST | `/api/widget/{botToken}/chat` | Send message, receive AI/agent response |
| GET | `/api/widget/{botToken}/history` | Conversation history |
| POST | `/api/widget/{botToken}/events` | Analytics events |

Domain validation is enforced when `require_domain_validation` is enabled on the chatbot.

---

## User roles

| Role | Capabilities |
|------|--------------|
| **Super Admin** | Full platform, all tenants |
| **Owner / Admin** | Company account, websites, users, analytics |
| **Manager** | Websites & settings (configurable restrictions) |
| **Agent** | Live inbox, assigned chats, leads |
| **Viewer** | Read-only dashboard access |

---

## Environment variables

```env
APP_NAME="AI Chatbot Hub Pro"
APP_URL=http://localhost:8000

DB_CONNECTION=mysql
DB_DATABASE=chatbot_hub

REDIS_HOST=127.0.0.1
QUEUE_CONNECTION=redis
CACHE_STORE=redis

OPENAI_API_KEY=sk-...
OPENAI_BASE_URL=https://api.openai.com/v1

AUTH_LOCKOUT_ATTEMPTS=5
AUTH_LOCKOUT_MINUTES=30
CHAT_SLA_MINUTES=15

BROADCAST_CONNECTION=reverb
REVERB_APP_ID=chatbot-hub
REVERB_APP_KEY=local-reverb-key
REVERB_APP_SECRET=local-reverb-secret
REVERB_HOST=localhost
REVERB_PORT=8080
REVERB_SCHEME=http
```

---

## Laravel Reverb (real-time WebSockets)

Install and enable Reverb for instant inbox updates (replaces HTTP polling on the agent dashboard):

```bash
composer require laravel/reverb
composer install
npm install
cp .env.example .env   # or merge Reverb vars into .env
php artisan key:generate
```

Set in `.env`:

```env
BROADCAST_CONNECTION=reverb
REVERB_APP_ID=chatbot-hub
REVERB_APP_KEY=local-reverb-key
REVERB_APP_SECRET=local-reverb-secret
REVERB_HOST=localhost
REVERB_PORT=8080
REVERB_SCHEME=http

VITE_REVERB_APP_KEY="${REVERB_APP_KEY}"
VITE_REVERB_HOST="${REVERB_HOST}"
VITE_REVERB_PORT="${REVERB_PORT}"
VITE_REVERB_SCHEME="${REVERB_SCHEME}"
```

Run all services:

```bash
composer dev
# serve + queue + reverb + logs + vite
```

Or separately:

```bash
php artisan reverb:start
php artisan queue:work
npm run dev
```

**Broadcast channels:**
- `private-organization.{id}` — inbox notifications, new chats
- `private-conversation.{id}` — live messages in open chat view

The embeddable widget still uses HTTP polling (visitors are not authenticated).

---

## Two-factor authentication (TOTP)

Users can enable 2FA from **My profile → Two-factor authentication**.

1. Confirm password → scan QR code (Google Authenticator, Authy, 1Password, etc.)
2. Enter the 6-digit code to confirm
3. Save the **recovery codes** shown once — use them if you lose your device

On sign-in, accounts with 2FA enabled are prompted for a TOTP code or recovery code at `/two-factor-challenge`.

Secrets and recovery codes are stored encrypted in the database.

---

## Social login (Google & GitHub)

Install Socialite and configure OAuth apps:

```bash
composer install
php artisan migrate
```

```env
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT_URI="${APP_URL}/auth/google/callback"

GITHUB_CLIENT_ID=
GITHUB_CLIENT_SECRET=
GITHUB_REDIRECT_URI="${APP_URL}/auth/github/callback"
```

**OAuth redirect URLs to register with each provider:**
- Google: `{APP_URL}/auth/google/callback`
- GitHub: `{APP_URL}/auth/github/callback`

Social buttons appear on login/register only when client ID and secret are set.

**Behavior:**
- Existing social account → sign in
- Email already registered → link provider to that account
- New user → creates organization + owner account (email marked verified)
- Works with 2FA — social sign-in still prompts for TOTP if enabled

---

## Development

```bash
composer dev
# Runs: serve + queue:listen + reverb + pail + vite
```

---

## Semantic search (OpenAI embeddings)

When enabled, knowledge base lookups use vector similarity before MySQL full-text search.

```env
SEMANTIC_SEARCH_ENABLED=true
OPENAI_API_KEY=sk-...
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
SEMANTIC_SEARCH_MIN_SCORE=0.72
```

New articles are embedded automatically when indexed. Backfill existing articles:

```bash
php artisan knowledge:embed
php artisan knowledge:embed 1   # single website ID
```

Requires a queue worker if handoff emails use the `database` queue driver.

---

## Roadmap (next phases)

- [ ] Vector store (pgvector/Qdrant) for large-scale embeddings
- [x] Website crawler & PDF/DOCX ingestion jobs
- [x] 2FA (TOTP) UI
- [x] Social login (Laravel Socialite)
- [x] Scheduled PDF/Excel reports
- [ ] WordPress plugin ZIP & Shopify app extension

---

## License

MIT
