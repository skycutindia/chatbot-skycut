<?php

use App\Http\Controllers\Api\WidgetChatController;
use App\Http\Controllers\Api\WidgetConfigController;
use App\Http\Controllers\Api\WidgetEventController;
use App\Http\Middleware\ResolveWebsiteByBotToken;
use App\Http\Middleware\ValidateWidgetDomain;
use Illuminate\Support\Facades\Route;

Route::prefix('widget/{botToken}')
    ->middleware([ResolveWebsiteByBotToken::class, ValidateWidgetDomain::class])
    ->group(function () {
        Route::get('/config', [WidgetConfigController::class, 'show']);
        Route::post('/chat', [WidgetChatController::class, 'store']);
        Route::get('/poll', [WidgetChatController::class, 'poll']);
        Route::get('/history', [WidgetChatController::class, 'history']);
        Route::post('/events', [WidgetEventController::class, 'store']);
    });
