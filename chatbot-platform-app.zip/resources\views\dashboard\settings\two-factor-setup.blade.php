@extends('layouts.app')

@section('title', 'Set up two-factor authentication')

@section('content')
<div class="max-w-2xl mx-auto">
    <h1 class="text-3xl font-bold">Set up two-factor authentication</h1>
    <p class="text-slate-400 mt-1">Scan the QR code, then enter the 6-digit code to confirm</p>

    <div class="mt-8 grid gap-6 md:grid-cols-2">
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col items-center justify-center">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={{ urlencode($qrUri) }}"
                 alt="QR code for authenticator app" width="200" height="200" class="rounded-lg bg-white p-2">
            <p class="text-xs text-slate-500 mt-4 text-center">Scan with your authenticator app</p>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <p class="text-sm text-slate-400">Or enter this key manually:</p>
            <p class="mt-2 font-mono text-sm break-all bg-slate-800 rounded-lg px-3 py-2 select-all">{{ $secret }}</p>

            <form method="POST" action="{{ route('settings.two-factor.confirm') }}" class="mt-6 space-y-4">
                @csrf
                <div>
                    <label class="block text-sm text-slate-400 mb-1">6-digit code</label>
                    <input type="text" name="code" inputmode="numeric" maxlength="6" required autofocus
                           placeholder="000000"
                           class="w-full rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white text-center text-lg tracking-widest focus:ring-2 focus:ring-indigo-500 outline-none">
                    @error('code')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
                </div>
                <button type="submit" class="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-sm font-medium">
                    Confirm and enable
                </button>
            </form>
        </div>
    </div>

    <form method="POST" action="{{ route('settings.two-factor.cancel') }}" class="mt-6">
        @csrf
        <button type="submit" class="text-sm text-slate-400 hover:text-slate-300">Cancel setup</button>
    </form>
</div>
@endsection
