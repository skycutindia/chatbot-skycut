import { onConversationEvent, onOrganizationEvent } from './echo';

const config = window.__CHATBOT_REALTIME__ ?? {};

function showToast(message) {
    let toast = document.getElementById('reverb-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'reverb-toast';
        toast.className = 'hidden fixed bottom-6 right-6 px-4 py-3 rounded-lg bg-indigo-600 text-white text-sm font-medium shadow-lg z-50';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 5000);
}

function appendInboxItem(data) {
    const list = document.getElementById('inbox-list');
    if (!list || document.querySelector(`[data-conversation-id="${data.conversation_id}"]`)) {
        return;
    }

    const el = document.createElement('div');
    el.dataset.conversationId = data.conversation_id;
    el.className = 'rounded-xl bg-slate-900 border border-amber-500/40 p-5 flex flex-wrap gap-4 justify-between items-center';
    el.innerHTML = `
        <div>
            <p class="font-medium">${data.visitor_name || 'Visitor'}</p>
            <p class="text-sm text-slate-500">${data.action} · just now</p>
            <span class="text-xs px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">${data.status}</span>
        </div>
        <a href="/websites/${data.website_id}/conversations/${data.conversation_id}" class="px-3 py-2 rounded-lg bg-indigo-600 text-sm">Open chat</a>
    `;
    list.prepend(el);
}

function appendChatMessage(message) {
    const list = document.getElementById('message-list');
    if (!list || document.querySelector(`[data-msg-id="${message.id}"]`)) {
        return;
    }

    const isVisitor = message.sender_type === 'visitor';
    const wrap = document.createElement('div');
    wrap.dataset.msgId = message.id;
    wrap.className = 'flex ' + (isVisitor ? 'justify-end' : 'justify-start');
    wrap.innerHTML = `
        <div class="max-w-[80%] rounded-2xl px-4 py-3 text-sm ${isVisitor ? 'bg-indigo-600' : 'bg-slate-800 border border-slate-700'}">
            ${escapeHtml(message.content)}
            <p class="text-xs opacity-60 mt-1">${message.source}</p>
        </div>
    `;
    list.appendChild(wrap);
    list.scrollTop = list.scrollHeight;
}

function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
}

if (config.orgId && window.Echo) {
    onOrganizationEvent(config.orgId, 'conversation.awaiting_agent', (data) => {
        showToast('New chat awaiting agent');
        if (config.page === 'inbox') {
            appendInboxItem({ ...data, action: 'handoff', status: 'awaiting_agent' });
        } else if (config.page !== 'conversation') {
            showToast('Open Live Inbox to respond');
        }
    });

    onOrganizationEvent(config.orgId, 'conversation.updated', (data) => {
        if (config.page === 'inbox' && data.action === 'handoff') {
            appendInboxItem(data);
        }
        const statusEl = document.getElementById('conv-status');
        if (statusEl && config.conversationId === data.conversation_id) {
            statusEl.textContent = data.status;
        }
    });

    onOrganizationEvent(config.orgId, 'message.sent', (message) => {
        if (config.page === 'inbox' || config.page === 'hub') {
            showToast('New message in live chat');
        }
        if (config.conversationId === message.conversation_id) {
            appendChatMessage(message);
        }
    });

    if (config.conversationId) {
        onConversationEvent(config.conversationId, 'message.sent', appendChatMessage);
        onConversationEvent(config.conversationId, 'conversation.updated', (data) => {
            const statusEl = document.getElementById('conv-status');
            if (statusEl) {
                statusEl.textContent = data.status;
            }
        });
    }
} else if (config.orgId) {
    setInterval(async () => {
        if (config.page !== 'inbox') return;
        try {
            const res = await fetch('/inbox/poll', { headers: { 'Accept': 'application/json' } });
            if (!res.ok) return;
            const data = await res.json();
            if (data.awaiting > 0) showToast(`${data.awaiting} chat(s) in queue`);
        } catch (_) {}
    }, 15000);
}

if (!window.Echo && config.page === 'conversation' && config.messagesUrl && config.conversationId) {
    let lastMessageId = 0;
    document.querySelectorAll('[data-msg-id]').forEach((el) => {
        const id = parseInt(el.dataset.msgId, 10);
        if (id > lastMessageId) lastMessageId = id;
    });

    setInterval(async () => {
        try {
            const url = `${config.messagesUrl}?after_id=${lastMessageId}`;
            const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
            if (!res.ok) return;
            const data = await res.json();
            data.messages?.forEach((message) => {
                appendChatMessage(message);
                if (message.id > lastMessageId) lastMessageId = message.id;
            });
            const statusEl = document.getElementById('conv-status');
            if (statusEl && data.status) {
                statusEl.textContent = data.status;
            }
        } catch (_) {}
    }, 1500);
}
