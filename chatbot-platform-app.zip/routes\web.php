<?php

use App\Http\Controllers\Admin\OrganizationController;
use App\Http\Controllers\Admin\PlatformSettingsController;
use App\Http\Controllers\Auth\EmailVerificationController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\Auth\SocialAuthController;
use App\Http\Controllers\Auth\TwoFactorChallengeController;
use App\Http\Controllers\Dashboard\AgentInboxController;
use App\Http\Controllers\Dashboard\AnalyticsController;
use App\Http\Controllers\Dashboard\CannedResponseController;
use App\Http\Controllers\Dashboard\ChatbotHubController;
use App\Http\Controllers\Dashboard\ConversationController;
use App\Http\Controllers\Dashboard\DashboardController;
use App\Http\Controllers\Dashboard\KnowledgeController;
use App\Http\Controllers\Dashboard\KnowledgeTrainingController;
use App\Http\Controllers\Dashboard\LeadController;
use App\Http\Controllers\Dashboard\OrganizationSettingsController;
use App\Http\Controllers\Dashboard\ProfileController;
use App\Http\Controllers\Dashboard\QaPairController;
use App\Http\Controllers\Dashboard\QuickActionController;
use App\Http\Controllers\Dashboard\ReportController;
use App\Http\Controllers\Dashboard\SearchController;
use App\Http\Controllers\Dashboard\SuggestedQuestionController;
use App\Http\Controllers\Dashboard\TeamController;
use App\Http\Controllers\Dashboard\TwoFactorController;
use App\Http\Controllers\Dashboard\WebsiteController;
use App\Http\Controllers\Dashboard\WidgetEmbedController;
use App\Http\Controllers\ExampleWebsiteController;
use App\Http\Middleware\EnsureOrganizationAccess;
use App\Http\Middleware\EnsureRole;
use App\Models\Website;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;

Route::get('/demo/{slug}', [ExampleWebsiteController::class, 'show'])->name('demo.show');

Route::get('/', function () {
    $slug = config('chatbot.demo_website_slug');

    if ($slug && Schema::hasTable('websites') && Website::query()->where('demo_slug', $slug)->where('is_active', true)->exists()) {
        return redirect()->route('demo.show', $slug);
    }

    return redirect()->route('login');
});

Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'show'])->name('login');
    Route::post('/login', [LoginController::class, 'store']);
    Route::get('/register', [RegisterController::class, 'show'])->name('register');
    Route::post('/register', [RegisterController::class, 'store']);
    Route::get('/forgot-password', [ForgotPasswordController::class, 'show'])->name('password.request');
    Route::post('/forgot-password', [ForgotPasswordController::class, 'store'])->name('password.email');
    Route::get('/reset-password/{token}', [ResetPasswordController::class, 'show'])->name('password.reset');
    Route::post('/reset-password', [ResetPasswordController::class, 'store'])->name('password.update');

    Route::get('/auth/{provider}/redirect', [SocialAuthController::class, 'redirect'])->name('social.redirect');
    Route::get('/auth/{provider}/callback', [SocialAuthController::class, 'callback'])->name('social.callback');
});

Route::get('/two-factor-challenge', [TwoFactorChallengeController::class, 'show'])->name('two-factor.login');
Route::post('/two-factor-challenge', [TwoFactorChallengeController::class, 'store'])
    ->middleware('throttle:6,1')
    ->name('two-factor.verify');

Route::post('/logout', [LoginController::class, 'destroy'])->middleware('auth')->name('logout');

Route::middleware('auth')->group(function () {
    Route::post('/auth/logout-beacon', [LoginController::class, 'beaconLogout'])->name('auth.logout-beacon');
    Route::get('/auth/session-expired', [LoginController::class, 'sessionExpired'])->name('auth.session-expired');
    Route::get('/email/verify', [EmailVerificationController::class, 'notice'])->name('verification.notice');
    Route::get('/email/verify/{id}/{hash}', [EmailVerificationController::class, 'verify'])
        ->middleware('signed')
        ->name('verification.verify');
    Route::post('/email/verification-notification', [EmailVerificationController::class, 'send'])
        ->middleware('throttle:6,1')
        ->name('verification.send');
});

Route::middleware(['auth', 'verified', 'dashboard.auth'])->group(function () {
    Route::get('/settings/two-factor', [TwoFactorController::class, 'show'])->name('settings.two-factor.show');
    Route::post('/settings/two-factor/enable', [TwoFactorController::class, 'enable'])->name('settings.two-factor.enable');
    Route::post('/settings/two-factor/confirm', [TwoFactorController::class, 'confirm'])->name('settings.two-factor.confirm');
    Route::get('/settings/two-factor/recovery-codes', [TwoFactorController::class, 'recoveryCodes'])->name('settings.two-factor.recovery-codes');
    Route::post('/settings/two-factor/recovery-codes', [TwoFactorController::class, 'regenerateRecoveryCodes'])->name('settings.two-factor.recovery-codes.regenerate');
    Route::post('/settings/two-factor/cancel', [TwoFactorController::class, 'cancelSetup'])->name('settings.two-factor.cancel');
    Route::delete('/settings/two-factor', [TwoFactorController::class, 'disable'])->name('settings.two-factor.disable');
});

Route::middleware(['auth', 'verified', 'dashboard.auth', EnsureRole::class.':super_admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/organizations', [OrganizationController::class, 'index'])->name('organizations.index');
    Route::get('/organizations/{organization}', [OrganizationController::class, 'show'])->name('organizations.show');
    Route::patch('/organizations/{organization}', [OrganizationController::class, 'update'])->name('organizations.update');
    Route::delete('/organizations/{organization}', [OrganizationController::class, 'destroy'])->name('organizations.destroy');
    Route::get('/settings', [PlatformSettingsController::class, 'edit'])->name('settings.edit');
    Route::put('/settings', [PlatformSettingsController::class, 'update'])->name('settings.update');
});

Route::middleware(['auth', 'verified', 'dashboard.auth', EnsureOrganizationAccess::class])->group(function () {
    Route::get('/dashboard', DashboardController::class)->name('dashboard');
    Route::get('/search', SearchController::class)->name('search');

    Route::get('/settings/profile', [ProfileController::class, 'edit'])->name('settings.profile.edit');
    Route::put('/settings/profile', [ProfileController::class, 'update'])->name('settings.profile.update');

    Route::middleware(EnsureRole::class.':super_admin,owner,admin')->group(function () {
        Route::get('/settings/organization', [OrganizationSettingsController::class, 'edit'])->name('settings.organization.edit');
        Route::put('/settings/organization', [OrganizationSettingsController::class, 'update'])->name('settings.organization.update');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin')->group(function () {
        Route::get('/team', [TeamController::class, 'index'])->name('team.index');
        Route::get('/team/create', [TeamController::class, 'create'])->name('team.create');
        Route::post('/team', [TeamController::class, 'store'])->name('team.store');
        Route::get('/team/{user}/edit', [TeamController::class, 'edit'])->name('team.edit');
        Route::patch('/team/{user}', [TeamController::class, 'update'])->name('team.update');
        Route::delete('/team/{user}', [TeamController::class, 'destroy'])->name('team.destroy');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin,manager,agent')->group(function () {
        Route::get('/canned-responses', [CannedResponseController::class, 'index'])->name('canned-responses.index');
        Route::post('/canned-responses', [CannedResponseController::class, 'store'])->name('canned-responses.store');
        Route::delete('/canned-responses/{cannedResponse}', [CannedResponseController::class, 'destroy'])->name('canned-responses.destroy');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin,manager,agent,viewer')->group(function () {
        Route::get('/inbox', [AgentInboxController::class, 'index'])->name('inbox.index');
        Route::get('/inbox/poll', [AgentInboxController::class, 'poll'])->name('inbox.poll');
        Route::post('/inbox/{conversation}/assign', [AgentInboxController::class, 'assign'])->name('inbox.assign');
        Route::post('/inbox/{conversation}/close', [AgentInboxController::class, 'close'])->name('inbox.close');
        Route::post('/inbox/{conversation}/reopen', [AgentInboxController::class, 'reopen'])->name('inbox.reopen');
        Route::post('/inbox/{conversation}/return-to-ai', [AgentInboxController::class, 'returnToAi'])->name('inbox.return-to-ai');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin,manager,viewer')->group(function () {
        Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
        Route::get('/reports/export', [ReportController::class, 'export'])->name('reports.export');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin,manager,viewer')->group(function () {
        Route::get('/leads', [LeadController::class, 'index'])->name('leads.index');
        Route::get('/leads/export', [LeadController::class, 'export'])->name('leads.export');
        Route::get('/leads/{lead}', [LeadController::class, 'show'])->name('leads.show');
        Route::patch('/leads/{lead}', [LeadController::class, 'update'])->name('leads.update');
        Route::post('/leads/{lead}/notes', [LeadController::class, 'storeNote'])->name('leads.notes.store');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin,manager,agent,viewer')->group(function () {
        Route::get('websites/{website}/hub', [ChatbotHubController::class, 'show'])->name('websites.hub');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin,manager')->group(function () {
        Route::resource('websites', WebsiteController::class);
        Route::get('websites/{website}/analytics', [AnalyticsController::class, 'show'])->name('websites.analytics');
        Route::get('websites/{website}/analytics/export', [AnalyticsController::class, 'export'])->name('websites.analytics.export');
        Route::get('websites/{website}/embed', [WidgetEmbedController::class, 'show'])->name('websites.embed');

        Route::get('websites/{website}/knowledge', [KnowledgeController::class, 'index'])->name('websites.knowledge.index');
        Route::get('websites/{website}/knowledge/training', [KnowledgeTrainingController::class, 'index'])->name('websites.knowledge.training');
        Route::post('websites/{website}/knowledge/crawl', [KnowledgeTrainingController::class, 'crawl'])->name('websites.knowledge.crawl');
        Route::post('websites/{website}/knowledge/upload', [KnowledgeTrainingController::class, 'upload'])->name('websites.knowledge.upload');
        Route::delete('websites/{website}/knowledge/sources/{source}', [KnowledgeTrainingController::class, 'destroy'])->name('websites.knowledge.sources.destroy');
        Route::post('websites/{website}/knowledge/articles', [KnowledgeController::class, 'storeArticle'])->name('websites.knowledge.articles.store');
        Route::post('websites/{website}/knowledge/categories', [KnowledgeController::class, 'storeCategory'])->name('websites.knowledge.categories.store');
        Route::delete('websites/{website}/knowledge/articles/{article}', [KnowledgeController::class, 'destroyArticle'])->name('websites.knowledge.articles.destroy');
        Route::post('websites/{website}/knowledge/import', [KnowledgeController::class, 'importFaq'])->name('websites.knowledge.import');

        Route::get('websites/{website}/quick-actions', [QuickActionController::class, 'index'])->name('websites.quick-actions.index');
        Route::post('websites/{website}/quick-actions', [QuickActionController::class, 'store'])->name('websites.quick-actions.store');
        Route::delete('websites/{website}/quick-actions/{quickAction}', [QuickActionController::class, 'destroy'])->name('websites.quick-actions.destroy');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin,manager,agent')->group(function () {
        Route::get('websites/{website}/conversations', [ConversationController::class, 'index'])->name('websites.conversations.index');
        Route::get('websites/{website}/conversations/{conversation}', [ConversationController::class, 'show'])->name('websites.conversations.show');
        Route::get('websites/{website}/conversations/{conversation}/messages', [ConversationController::class, 'messages'])->name('websites.conversations.messages');
        Route::post('websites/{website}/conversations/{conversation}/reply', [ConversationController::class, 'reply'])->name('websites.conversations.reply');
        Route::post('websites/{website}/conversations/{conversation}/close', [ConversationController::class, 'close'])->name('websites.conversations.close');
        Route::post('websites/{website}/conversations/{conversation}/reopen', [ConversationController::class, 'reopen'])->name('websites.conversations.reopen');
        Route::post('websites/{website}/conversations/{conversation}/notes', [ConversationController::class, 'storeNote'])->name('websites.conversations.notes.store');
        Route::post('websites/{website}/conversations/{conversation}/return-to-ai', [ConversationController::class, 'returnToAi'])->name('websites.conversations.return-to-ai');
    });

    Route::middleware(EnsureRole::class.':super_admin,owner,admin,manager')->group(function () {
        Route::post('websites/{website}/qa-pairs', [QaPairController::class, 'store'])->name('websites.qa.store');
        Route::delete('websites/{website}/qa-pairs/{qaPair}', [QaPairController::class, 'destroy'])->name('websites.qa.destroy');
        Route::post('websites/{website}/suggested-questions', [SuggestedQuestionController::class, 'store'])->name('websites.questions.store');
        Route::delete('websites/{website}/suggested-questions/{question}', [SuggestedQuestionController::class, 'destroy'])->name('websites.questions.destroy');
    });
});

Route::bind('website', function ($value) {
    $website = Website::findOrFail($value);
    if (auth()->check() && auth()->user()->organization_id && $website->organization_id !== auth()->user()->organization_id) {
        abort(403);
    }

    return $website;
});

Route::bind('conversation', fn ($value) => \App\Models\Conversation::findOrFail($value));
Route::bind('lead', fn ($value) => \App\Models\Lead::findOrFail($value));
Route::bind('organization', fn ($value) => \App\Models\Organization::findOrFail($value));
Route::bind('user', function ($value) {
    $user = \App\Models\User::findOrFail($value);
    if (auth()->check() && auth()->user()->organization_id && $user->organization_id !== auth()->user()->organization_id) {
        abort(403);
    }

    return $user;
});
Route::bind('cannedResponse', fn ($value) => \App\Models\CannedResponse::findOrFail($value));
Route::bind('source', fn ($value) => \App\Models\KnowledgeSource::findOrFail($value));
