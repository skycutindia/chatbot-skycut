@extends('layouts.app')

@section('title', 'Add team member')

@section('content')
<div class="max-w-lg mx-auto">
    <a href="{{ route('team.index') }}" class="text-sm text-indigo-400">← Team</a>
    <h1 class="text-2xl font-bold mt-4">Add team member</h1>
    <form method="POST" action="{{ route('team.store') }}" class="mt-6 space-y-4 rounded-xl bg-slate-900 border border-slate-800 p-6">
        @csrf
        <input name="name" placeholder="Full name" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <input type="email" name="email" placeholder="Email" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <input type="password" name="password" placeholder="Password" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <input type="password" name="password_confirmation" placeholder="Confirm password" required class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        <select name="role" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            @foreach($roles as $role)
                <option value="{{ $role }}">{{ \App\Enums\UserRole::from($role)->label() }}</option>
            @endforeach
        </select>
        <button class="w-full py-2 rounded-lg bg-indigo-600 text-sm font-medium">Create account</button>
    </form>
</div>
@endsection
