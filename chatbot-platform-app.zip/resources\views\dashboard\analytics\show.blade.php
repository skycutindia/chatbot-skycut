@extends('layouts.app')

@section('title', 'Analytics')

@section('content')
<div class="max-w-5xl mx-auto">
    <div class="flex flex-wrap gap-4 justify-between items-center">
        <h1 class="text-3xl font-bold">Analytics</h1>
        <a href="{{ route('websites.analytics.export', $website) }}" class="px-4 py-2 rounded-lg bg-emerald-600 text-sm">Export CSV</a>
    </div>
    <p class="text-slate-400">{{ $website->name }} — last {{ $summary['period_days'] }} days</p>

    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">Conversations</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['conversations'] }}</p>
            <p class="text-xs text-slate-500 mt-1">{{ $summary['open_conversations'] }} open now</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">Leads</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['leads'] }}</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">Handoff rate</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['handoff_rate'] }}%</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">AI resolution</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['ai_resolution_rate'] }}%</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">Messages</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['messages'] }}</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">Widget opens</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['widget_opens'] }}</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">Widget loads</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['widget_loads'] }}</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">Avg satisfaction</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['avg_satisfaction'] ? $summary['avg_satisfaction'].'/5' : '—' }}</p>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <p class="text-slate-400 text-sm">Human handoffs</p>
            <p class="text-3xl font-bold mt-1">{{ $summary['handoffs'] }}</p>
        </div>
    </div>

    @if($summary['events']->isNotEmpty())
        <div class="mt-8 rounded-xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold mb-4">Events breakdown</h2>
            <ul class="space-y-2 text-sm">
                @foreach($summary['events'] as $type => $count)
                    <li class="flex justify-between"><span>{{ $type }}</span><span>{{ $count }}</span></li>
                @endforeach
            </ul>
        </div>
    @endif
</div>
@endsection
