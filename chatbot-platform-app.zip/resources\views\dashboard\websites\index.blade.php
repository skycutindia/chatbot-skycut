﻿@extends('layouts.app')

@section('title', 'Websites')

@section('content')
<div class="max-w-6xl mx-auto">
    <div class="flex justify-between items-center">
        <h1 class="text-3xl font-bold">Websites</h1>
        <a href="{{ route('websites.create') }}" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-sm font-medium">+ New website</a>
    </div>

    <div class="mt-8 space-y-3">
        @foreach($websites as $site)
            <a href="{{ route('websites.show', $site) }}" class="flex justify-between items-center rounded-xl bg-slate-900 border border-slate-800 p-5 hover:border-indigo-500/50">
                <div>
                    <h3 class="font-semibold">{{ $site->name }}</h3>
                    <code class="text-xs text-slate-500 mt-1">{{ Str::limit($site->bot_token, 24) }}â€¦</code>
                </div>
                <span class="text-sm text-slate-400">Configure â†’</span>
            </a>
        @endforeach
    </div>
    <div class="mt-6">{{ $websites->links() }}</div>
</div>
@endsection


