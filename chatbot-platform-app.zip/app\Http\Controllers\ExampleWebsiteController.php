<?php

namespace App\Http\Controllers;

use App\Models\Website;
use Illuminate\View\View;

class ExampleWebsiteController extends Controller
{
    public function show(string $slug): View
    {
        $website = Website::query()
            ->where('demo_slug', $slug)
            ->where('is_active', true)
            ->where('widget_enabled', true)
            ->with('configuration')
            ->firstOrFail();

        return view('demo.storefront', compact('website'));
    }
}
