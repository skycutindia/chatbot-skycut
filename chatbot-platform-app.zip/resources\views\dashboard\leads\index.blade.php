@extends('layouts.app')

@section('title', 'Leads')

@section('content')
<div class="max-w-6xl mx-auto">
    <div class="flex flex-wrap gap-4 justify-between items-center">
        <div>
            <h1 class="text-3xl font-bold">Lead CRM</h1>
            <p class="text-slate-400 mt-1">Automatically captured from chat conversations</p>
        </div>
        <a href="{{ route('leads.export') }}" class="px-4 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm">Export CSV</a>
    </div>

    <form method="GET" class="mt-6 flex flex-wrap gap-3">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search name, email, company..." class="rounded-lg bg-slate-900 border border-slate-700 px-4 py-2 text-sm flex-1 min-w-[200px]">
        <select name="status" class="rounded-lg bg-slate-900 border border-slate-700 px-4 py-2 text-sm">
            <option value="">All statuses</option>
            @foreach($statuses as $status)
                <option value="{{ $status->value }}" @selected(request('status') === $status->value)>{{ $status->label() }}</option>
            @endforeach
        </select>
        <button class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Filter</button>
    </form>

    <div class="mt-6 overflow-x-auto rounded-xl border border-slate-800">
        <table class="w-full text-sm">
            <thead class="bg-slate-900 text-slate-400 text-left">
                <tr>
                    <th class="p-4">Lead</th>
                    <th class="p-4">Website</th>
                    <th class="p-4">Status</th>
                    <th class="p-4">Created</th>
                </tr>
            </thead>
            <tbody>
                @forelse($leads as $lead)
                    <tr class="border-t border-slate-800 hover:bg-slate-900/50">
                        <td class="p-4">
                            <a href="{{ route('leads.show', $lead) }}" class="font-medium text-indigo-300 hover:text-indigo-200">
                                {{ $lead->name ?: $lead->email ?: 'Anonymous' }}
                            </a>
                            <p class="text-slate-500 text-xs mt-0.5">{{ $lead->email }}</p>
                        </td>
                        <td class="p-4 text-slate-400">{{ $lead->website?->name }}</td>
                        <td class="p-4"><span class="px-2 py-1 rounded bg-slate-800 text-xs">{{ $lead->statusEnum()->label() }}</span></td>
                        <td class="p-4 text-slate-500">{{ $lead->created_at?->diffForHumans() }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4" class="p-8 text-center text-slate-500">No leads yet. They appear when visitors share contact info in chat.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="mt-4">{{ $leads->links() }}</div>
</div>
@endsection
