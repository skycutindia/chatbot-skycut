@extends('layouts.app')

@section('title', 'Recovery codes')

@section('content')
<div class="max-w-2xl mx-auto">
    <h1 class="text-3xl font-bold">Recovery codes</h1>
    <p class="text-slate-400 mt-1">Store these codes in a safe place. Each code can only be used once.</p>

    @if($codes)
        <div class="mt-8 bg-amber-500/10 border border-amber-500/30 rounded-2xl px-6 py-4 text-amber-200 text-sm">
            Copy these codes now. They will not be shown again unless you regenerate them.
        </div>

        <ul class="mt-6 grid gap-2 sm:grid-cols-2 font-mono text-sm bg-slate-900 border border-slate-800 rounded-2xl p-6">
            @foreach($codes as $code)
                <li class="px-3 py-2 rounded bg-slate-800">{{ $code }}</li>
            @endforeach
        </ul>
    @else
        <div class="mt-8 bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <p class="text-sm text-slate-400">Recovery codes are hidden for security. Regenerate new codes if you need a fresh set.</p>
            <form method="POST" action="{{ route('settings.two-factor.recovery-codes.regenerate') }}" class="mt-4 space-y-3">
                @csrf
                <div>
                    <label class="block text-sm text-slate-400 mb-1">Confirm your password</label>
                    <input type="password" name="password" required
                           class="w-full max-w-xs rounded-lg bg-slate-800 border border-slate-700 px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none">
                    @error('password')<p class="text-red-400 text-sm mt-1">{{ $message }}</p>@enderror
                </div>
                <button type="submit" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-sm font-medium">
                    Generate new recovery codes
                </button>
            </form>
        </div>
    @endif

    <p class="mt-6 text-sm">
        <a href="{{ route('settings.two-factor.show') }}" class="text-indigo-400 hover:text-indigo-300">← Back to two-factor settings</a>
    </p>
</div>
@endsection
