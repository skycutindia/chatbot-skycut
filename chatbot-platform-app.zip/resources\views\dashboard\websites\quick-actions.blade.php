@extends('layouts.app')

@section('title', 'Quick actions')

@section('content')
<div class="max-w-4xl mx-auto">
    <a href="{{ route('websites.show', $website) }}" class="text-sm text-indigo-400">← Back</a>
    <h1 class="text-3xl font-bold mt-4">Quick actions — {{ $website->name }}</h1>
    <p class="text-slate-400 mt-1">Get Quote, Book Demo, WhatsApp, and more</p>

    <ul class="mt-8 space-y-3">
        @foreach($website->quickActions as $action)
            <li class="flex justify-between items-center rounded-xl bg-slate-900 border border-slate-800 p-4">
                <div>
                    <span class="font-medium">{{ $action->label }}</span>
                    <span class="text-xs text-slate-500 ml-2">{{ $action->action_type }} → {{ $action->action_value }}</span>
                </div>
                <form method="POST" action="{{ route('websites.quick-actions.destroy', [$website, $action]) }}">
                    @csrf @method('DELETE')
                    <button class="text-red-400 text-sm">Remove</button>
                </form>
            </li>
        @endforeach
    </ul>

    <form method="POST" action="{{ route('websites.quick-actions.store', $website) }}" class="mt-8 rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4">
        @csrf
        <div class="grid md:grid-cols-2 gap-4">
            <input type="text" name="label" placeholder="Label (e.g. Get Quote)" required class="rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            <input type="text" name="icon" placeholder="Icon (optional emoji or class)" class="rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
            <select name="action_type" class="rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
                <option value="url">URL</option>
                <option value="email">Email</option>
                <option value="phone">Phone</option>
                <option value="internal">Internal action</option>
            </select>
            <input type="text" name="action_value" placeholder="https://... or mailto:..." class="rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        </div>
        <button class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Add quick action</button>
    </form>
</div>
@endsection
