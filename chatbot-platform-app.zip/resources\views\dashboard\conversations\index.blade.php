@extends('layouts.app')

@section('title', 'Conversations')

@section('content')
<div class="max-w-5xl mx-auto">
    <h1 class="text-3xl font-bold">Conversations</h1>
    <p class="text-slate-400">{{ $website->name }}</p>

    <div class="mt-8 space-y-3">
        @forelse($conversations as $conv)
            <a href="{{ route('websites.conversations.show', [$website, $conv]) }}"
               class="block rounded-xl bg-slate-900 border border-slate-800 p-5 hover:border-indigo-500/50">
                <div class="flex justify-between">
                    <span class="font-medium">{{ $conv->visitor_name ?? 'Visitor' }} <span class="text-slate-500 text-sm">#{{ Str::limit($conv->visitor_id, 8) }}</span></span>
                    <span class="text-xs px-2 py-1 rounded bg-slate-800">{{ $conv->status }}</span>
                </div>
                <p class="text-sm text-slate-500 mt-1">{{ $conv->last_message_at?->diffForHumans() }}</p>
            </a>
        @empty
            <p class="text-slate-500">No conversations yet.</p>
        @endforelse
    </div>
    {{ $conversations->links() }}
</div>
@endsection
