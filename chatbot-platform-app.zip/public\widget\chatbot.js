/**
 * SkyCut-style embeddable chatbot widget — Laravel AI Chatbot Hub Pro
 */
(function () {
  'use strict';

  const script = document.currentScript;
  const botToken = script?.getAttribute('data-bot-token');
  if (!botToken) {
    console.error('[ChatFlow] Missing data-bot-token attribute.');
    return;
  }

  const inlineTarget = script?.getAttribute('data-inline');
  const autoOpen = script?.getAttribute('data-auto-open') === 'true';
  const instanceKey = botToken + (inlineTarget || 'float');

  if (window.__chatflowInstances?.[instanceKey]) {
    return;
  }
  window.__chatflowInstances = window.__chatflowInstances || {};
  window.__chatflowInstances[instanceKey] = true;

  const apiBase = (() => {
    const src = script.src || '';
    try {
      return new URL(src).origin;
    } catch {
      return window.location.origin;
    }
  })();

  const cssBase = (() => {
    const src = script.src || '';
    try {
      return new URL('.', src).href;
    } catch {
      return apiBase + '/widget/';
    }
  })();

  const STORAGE_KEY = 'chatflow_' + botToken;
  const ICONS = {
    chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    send: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>',
    bot: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="3"/><path d="M8 15h.01M16 15h.01"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>',
    minimize: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/></svg>',
    user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  };

  const state = {
    config: null,
    open: autoOpen || !!inlineTarget,
    inline: !!inlineTarget,
    visitorId: null,
    conversationId: null,
    messages: [],
    loading: false,
    typing: false,
    pollTimer: null,
    handoff: false,
    rated: false,
    humanMode: false,
    unread: false,
  };

  function storageGet() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    } catch {
      return {};
    }
  }

  function storageSet(data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...storageGet(), ...data }));
  }

  function getVisitorId() {
    const saved = storageGet().visitorId;
    if (saved) return saved;
    const id = 'v_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
    storageSet({ visitorId: id });
    return id;
  }

  async function api(path, options = {}) {
    const url = apiBase + '/api/widget/' + botToken + path;
    const res = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...(options.headers || {}),
      },
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || res.statusText);
    }
    return res.json();
  }

  function t(key, fallback) {
    const locale = state.config?.locale || 'en';
    const tr = state.config?.translations?.[locale];
    return (tr && tr[key]) || fallback;
  }

  function injectStyles() {
    if (document.getElementById('chatflow-styles-link')) return;
    const link = document.createElement('link');
    link.id = 'chatflow-styles-link';
    link.rel = 'stylesheet';
    link.href = cssBase + 'chatbot.css';
    document.head.appendChild(link);

    if (!document.querySelector('link[href*="fonts.googleapis.com"][href*="Inter"]')) {
      const font = document.createElement('link');
      font.rel = 'stylesheet';
      font.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
      document.head.appendChild(font);
    }
  }

  function applyTheme() {
    const root = document.getElementById('chatflow-root');
    if (!root || !state.config) return;
    const a = state.config.appearance;
    const theme = a.theme_mode === 'auto'
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : (a.theme_mode || 'light');
    root.dataset.theme = theme;
    root.style.setProperty('--cf-primary', a.primary_color || '#0d9488');
    root.style.setProperty('--cf-primary-light', a.secondary_color || '#14b8a6');
    root.style.setProperty('--cf-user-bubble', a.primary_color || '#0d9488');
    if (a.custom_css) {
      let style = document.getElementById('chatflow-custom-css');
      if (!style) {
        style = document.createElement('style');
        style.id = 'chatflow-custom-css';
        document.head.appendChild(style);
      }
      style.textContent = a.custom_css;
    }
  }

  function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s || '';
    return d.innerHTML;
  }

  function formatTime(dateStr) {
    if (!dateStr) return '';
    try {
      return new Date(dateStr).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  }

  function render() {
    let root = document.getElementById('chatflow-root');
    const host = inlineTarget ? document.querySelector(inlineTarget) : null;

    if (!root) {
      root = document.createElement('div');
      root.id = 'chatflow-root';
      if (host) {
        host.appendChild(root);
      } else {
        document.body.appendChild(root);
      }
    }

    const cfg = state.config;
    const pos = cfg?.appearance?.position || 'right';
    root.dataset.position = pos;
    root.dataset.mode = state.inline ? 'inline' : 'floating';
    root.classList.toggle('open', state.open);
    root.dataset.unread = state.unread && !state.open ? 'true' : 'false';

    const botName = cfg?.appearance?.bot_name || 'Assistant';
    const avatar = cfg?.appearance?.avatar_url;
    const isOnline = cfg?.operating_hours?.is_open !== false;
    const statusLabel = isOnline ? 'Online' : 'Offline';

    const avatarHtml = avatar
      ? `<img src="${escapeHtml(avatar)}" alt="">`
      : ICONS.bot;

    root.innerHTML = `
      ${state.inline ? '' : `<button id="chatflow-launcher" aria-label="Open chat" type="button">${state.open ? ICONS.close : ICONS.chat}</button>`}
      <div id="chatflow-panel" role="dialog" aria-label="${escapeHtml(botName)}">
        <div id="chatflow-header">
          <div class="cf-header-avatar">${avatarHtml}</div>
          <div class="cf-header-info">
            <strong>${escapeHtml(botName)}</strong>
            <div class="cf-header-status">
              <span class="cf-status-dot ${isOnline ? '' : 'offline'}"></span>
              ${statusLabel}
            </div>
          </div>
          <div class="cf-header-actions">
            ${state.inline ? '' : `<button type="button" class="cf-icon-btn" id="chatflow-minimize" aria-label="Minimize">${ICONS.minimize}</button>`}
            ${state.inline ? '' : `<button type="button" class="cf-icon-btn" id="chatflow-close" aria-label="Close">${ICONS.close}</button>`}
          </div>
        </div>
        <div id="chatflow-messages"></div>
        <div id="chatflow-typing-area"></div>
        <div id="chatflow-suggestions"></div>
        <div id="chatflow-actions"></div>
        <div id="chatflow-footer">
          <div class="cf-input-wrap">
            <input id="chatflow-input" type="text" placeholder="${escapeHtml(t('input_placeholder', 'Type a message...'))}" ${state.loading ? 'disabled' : ''} />
            <button id="chatflow-send" type="button" aria-label="Send" ${state.loading ? 'disabled' : ''}>${ICONS.send}</button>
          </div>
          <div class="cf-powered">Powered by AI Chatbot Hub Pro</div>
        </div>
      </div>
      ${state.inline ? '' : `
      <div id="chatflow-satisfaction">
        <div class="cf-sat-icon">${ICONS.chat}</div>
        <div class="cf-sat-text">
          <strong>Satisfaction</strong>
          <span>98.5% positive</span>
        </div>
      </div>`}
    `;

    applyTheme();
    bindEvents();
    renderMessages();
    renderTyping();
    renderSuggestions();
    renderQuickActions();
  }

  function renderMessages() {
    const box = document.getElementById('chatflow-messages');
    if (!box) return;

    if (!state.messages.length && state.open && state.config?.messages?.welcome) {
      box.innerHTML = `
        <div class="cf-row cf-row-bot">
          <div class="cf-msg-avatar cf-msg-avatar-bot">${ICONS.bot}</div>
          <div>
            <div class="cf-bubble cf-bubble-bot">${escapeHtml(state.config.messages.welcome)}</div>
          </div>
        </div>`;
      box.scrollTop = box.scrollHeight;
      return;
    }

    box.innerHTML = state.messages
      .map((m) => {
        const isUser = m.sender_type === 'visitor';
        const isAgent = m.sender_type === 'agent';
        const bubbleClass = isUser ? 'cf-bubble-user' : isAgent ? 'cf-bubble-agent' : 'cf-bubble-bot';
        const rowClass = isUser ? 'cf-row-user' : 'cf-row-bot';
        const avatar = isUser
          ? `<div class="cf-msg-avatar cf-msg-avatar-user">${ICONS.user}</div>`
          : `<div class="cf-msg-avatar cf-msg-avatar-bot">${ICONS.bot}</div>`;

        return `
          <div class="cf-row ${rowClass}">
            ${avatar}
            <div>
              <div class="cf-bubble ${bubbleClass}">${escapeHtml(m.content)}</div>
              ${m.created_at ? `<div class="cf-time">${formatTime(m.created_at)}</div>` : ''}
            </div>
          </div>`;
      })
      .join('');
    box.scrollTop = box.scrollHeight;
  }

  function renderTyping() {
    const el = document.getElementById('chatflow-typing-area');
    if (!el) return;
    if (!state.typing) {
      el.innerHTML = '';
      return;
    }
    el.innerHTML = `
      <div class="cf-typing-wrap">
        <div class="cf-row cf-row-bot">
          <div class="cf-msg-avatar cf-msg-avatar-bot">${ICONS.bot}</div>
          <div class="cf-bubble cf-bubble-bot cf-typing-bubble">
            <span></span><span></span><span></span>
          </div>
        </div>
      </div>`;
    const box = document.getElementById('chatflow-messages');
    if (box) box.scrollTop = box.scrollHeight;
  }

  function renderSuggestions() {
    const el = document.getElementById('chatflow-suggestions');
    if (!el || !state.config?.modules?.suggested_questions) return;
    const qs = state.config.suggested_questions || [];
    el.innerHTML = qs.length
      ? qs.map((q) => `<button type="button" class="cf-chip" data-q="${escapeHtml(q)}">${escapeHtml(q)}</button>`).join('')
      : '';
    el.querySelectorAll('.cf-chip').forEach((btn) => {
      btn.addEventListener('click', () => sendMessage(btn.dataset.q));
    });
  }

  function renderQuickActions() {
    const el = document.getElementById('chatflow-actions');
    if (!el) return;
    const actions = state.config?.quick_actions || [];
    el.innerHTML = actions.length
      ? actions.map((a) =>
          `<button type="button" class="cf-action" data-type="${escapeHtml(a.action_type)}" data-value="${escapeHtml(a.action_value || '')}">${escapeHtml(a.icon || '')} ${escapeHtml(a.label)}</button>`
        ).join('')
      : '';
    el.querySelectorAll('.cf-action').forEach((btn) => {
      btn.addEventListener('click', () => handleQuickAction(btn.dataset.type, btn.dataset.value, btn.textContent.trim()));
    });
  }

  function handleQuickAction(type, value, label) {
    if (type === 'url' && value) {
      window.open(value, '_blank', 'noopener');
      trackEvent('quick_action', { type, value });
      return;
    }
    if (type === 'email' && value) {
      window.location.href = 'mailto:' + value;
      return;
    }
    if (type === 'phone' && value) {
      window.location.href = 'tel:' + value;
      return;
    }
    if (type === 'message' && value) {
      sendMessage(value);
      return;
    }
    sendMessage(label || value || 'Help');
  }

  function getPollInterval() {
    if (state.handoff || state.humanMode) return 1000;
    if (state.conversationId) return 1500;
    return 4000;
  }

  function startPolling() {
    stopPolling();
    if (!state.conversationId) return;
    const tick = async () => {
      await pollMessages();
      state.pollTimer = setTimeout(tick, getPollInterval());
    };
    state.pollTimer = setTimeout(tick, 500);
  }

  function stopPolling() {
    if (state.pollTimer) {
      clearTimeout(state.pollTimer);
      state.pollTimer = null;
    }
  }

  async function pollMessages() {
    if (!state.conversationId) return;
    try {
      const lastId = state.messages.reduce((max, m) => Math.max(max, m.id || 0), 0);
      const res = await api(
        '/poll?visitor_id=' + encodeURIComponent(state.visitorId) +
        '&conversation_id=' + state.conversationId +
        '&after_id=' + lastId
      );
      let added = false;
      (res.messages || []).forEach((m) => {
        if (!state.messages.some((x) => x.id === m.id)) {
          state.messages.push({
            id: m.id,
            sender_type: m.sender_type,
            content: m.content,
            source: m.source,
            created_at: m.created_at,
          });
          added = true;
        }
      });
      if (added) {
        if (!state.open) {
          state.unread = true;
        }
        renderMessages();
        const launcher = document.getElementById('chatflow-launcher');
        if (launcher && !state.open) {
          launcher.classList.add('pulse');
        }
      }
      state.handoff = res.handoff || state.handoff;
      state.humanMode = res.mode === 'human' || state.humanMode;
    } catch (_) {}
  }

  function bindEvents() {
    document.getElementById('chatflow-launcher')?.addEventListener('click', toggle);
    document.getElementById('chatflow-close')?.addEventListener('click', () => closePanel());
    document.getElementById('chatflow-minimize')?.addEventListener('click', () => closePanel());
    document.getElementById('chatflow-send')?.addEventListener('click', () => {
      const input = document.getElementById('chatflow-input');
      if (input?.value.trim()) sendMessage(input.value.trim());
    });
    document.getElementById('chatflow-input')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        const input = e.target;
        if (input.value.trim()) sendMessage(input.value.trim());
      }
    });
  }

  function openPanel() {
    state.open = true;
    state.unread = false;
    if (state.messages.length === 0 && state.config?.messages?.welcome && !state.inline) {
      /* welcome rendered in renderMessages when empty */
    }
    trackEvent('widget_open');
    render();
  }

  function closePanel() {
    if (state.open && state.messages.length > 0 && state.conversationId) {
      promptRating();
    }
    state.open = false;
    render();
  }

  function toggle() {
    if (state.open) closePanel();
    else openPanel();
  }

  function addMessage(senderType, content, source, id, createdAt) {
    state.messages.push({
      id: id || null,
      sender_type: senderType,
      content,
      source,
      created_at: createdAt || new Date().toISOString(),
    });
    renderMessages();
  }

  async function promptRating() {
    if (!state.conversationId || state.rated) return;
    state.rated = true;
    await trackEvent('conversation_rating', { score: 5, comment: null });
  }

  async function trackEvent(type, payload = {}) {
    if (!state.config?.modules?.analytics) return;
    try {
      await api('/events', {
        method: 'POST',
        body: JSON.stringify({
          event_type: type,
          visitor_id: state.visitorId,
          conversation_id: state.conversationId,
          payload,
        }),
      });
    } catch (_) {}
  }

  async function sendMessage(text) {
    if (state.loading) return;
    const input = document.getElementById('chatflow-input');
    if (input) input.value = '';

    if (!state.config?.operating_hours?.is_open) {
      addMessage('bot', state.config?.messages?.outside_hours || state.config?.messages?.offline || 'We are offline.', 'offline');
      return;
    }

    if (!state.open) openPanel();

    addMessage('visitor', text, 'user');
    state.loading = true;
    state.typing = state.config?.modules?.typing_indicator !== false;
    renderTyping();
    const sendBtn = document.getElementById('chatflow-send');
    const inputEl = document.getElementById('chatflow-input');
    if (sendBtn) sendBtn.disabled = true;
    if (inputEl) inputEl.disabled = true;

    try {
      const res = await api('/chat', {
        method: 'POST',
        body: JSON.stringify({
          message: text,
          visitor_id: state.visitorId,
          conversation_id: state.conversationId,
          page_url: window.location.href,
        }),
      });

      if (res.conversation_id) {
        state.conversationId = res.conversation_id;
        storageSet({ conversationId: res.conversation_id });
        startPolling();
      }

      if (res.offline && res.message) {
        addMessage('bot', res.message.content, res.message.source, res.message.id);
      } else if (res.message) {
        addMessage('bot', res.message.content, res.message.source, res.message.id);
      }

      if (res.handoff) {
        state.handoff = true;
        startPolling();
      }
      if (res.status === 'open' && res.mode === 'human') {
        state.humanMode = true;
        startPolling();
      }

      trackEvent('message_sent');
    } catch (err) {
      addMessage('bot', 'Sorry, something went wrong. Please try again.', 'error');
    } finally {
      state.loading = false;
      state.typing = false;
      render();
    }
  }

  async function loadConfig() {
    state.visitorId = getVisitorId();
    const saved = storageGet();
    state.conversationId = saved.conversationId || null;

    state.config = await api('/config?visitor_id=' + encodeURIComponent(state.visitorId));

    try {
      const history = await api(
        '/history?visitor_id=' + encodeURIComponent(state.visitorId) +
        (state.conversationId ? '&conversation_id=' + state.conversationId : '')
      );
      if (history.messages?.length) {
        state.messages = history.messages.map((m) => ({
          id: m.id,
          sender_type: m.sender_type,
          content: m.content,
          source: m.source,
          created_at: m.created_at,
        }));
        state.conversationId = history.conversation_id;
        state.humanMode = history.mode === 'human';
        startPolling();
      }
    } catch (_) {}

    if (state.config?.appearance?.auto_open && !state.inline) {
      state.open = true;
    }

    if (state.config?.appearance?.custom_js) {
      try {
        new Function(state.config.appearance.custom_js)();
      } catch (e) {
        console.warn('[ChatFlow] custom_js error', e);
      }
    }
  }

  async function init() {
    injectStyles();
    state.visitorId = getVisitorId();
    try {
      await loadConfig();
      render();
      trackEvent('widget_loaded');
    } catch (err) {
      console.error('[ChatFlow] Failed to load config:', err.message);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
