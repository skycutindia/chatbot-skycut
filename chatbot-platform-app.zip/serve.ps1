# Start AI Chatbot Hub Pro dev server (Windows)
# Uses php-cli.ini so OpenSSL and PDO extensions load correctly.

$AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $AppRoot

$ini = Join-Path $AppRoot "php-cli.ini"
Write-Host "Starting server at http://127.0.0.1:8000" -ForegroundColor Cyan
Write-Host "Press Ctrl+C to stop.`n"

php -c $ini -S 127.0.0.1:8000 -t public
