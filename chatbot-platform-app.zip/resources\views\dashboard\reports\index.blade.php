@extends('layouts.app')

@section('title', 'Reports')

@section('content')
<div class="max-w-6xl mx-auto">
    <div class="flex flex-wrap gap-4 justify-between items-center">
        <div>
            <h1 class="text-3xl font-bold">Reports</h1>
            <p class="text-slate-400 mt-1">Organization-wide analytics — last {{ $days }} days</p>
        </div>
        <div class="flex gap-2">
            <a href="{{ route('reports.index', ['days' => 7]) }}" class="px-3 py-2 rounded-lg text-sm {{ $days === 7 ? 'bg-indigo-600' : 'bg-slate-800' }}">7d</a>
            <a href="{{ route('reports.index', ['days' => 30]) }}" class="px-3 py-2 rounded-lg text-sm {{ $days === 30 ? 'bg-indigo-600' : 'bg-slate-800' }}">30d</a>
            <a href="{{ route('reports.index', ['days' => 90]) }}" class="px-3 py-2 rounded-lg text-sm {{ $days === 90 ? 'bg-indigo-600' : 'bg-slate-800' }}">90d</a>
            <a href="{{ route('reports.export', ['days' => $days, 'format' => 'csv']) }}" class="px-4 py-2 rounded-lg bg-emerald-600 text-sm">CSV</a>
            <a href="{{ route('reports.export', ['days' => $days, 'format' => 'excel']) }}" class="px-4 py-2 rounded-lg bg-emerald-700 text-sm">Excel</a>
            <a href="{{ route('reports.export', ['days' => $days, 'format' => 'pdf']) }}" class="px-4 py-2 rounded-lg bg-emerald-800 text-sm">PDF</a>
        </div>
    </div>

    <div class="grid md:grid-cols-4 gap-4 mt-8">
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-5"><p class="text-slate-400 text-sm">Conversations</p><p class="text-2xl font-bold mt-1">{{ $totals['conversations'] }}</p></div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-5"><p class="text-slate-400 text-sm">Leads</p><p class="text-2xl font-bold mt-1">{{ $totals['leads'] }}</p></div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-5"><p class="text-slate-400 text-sm">Handoffs</p><p class="text-2xl font-bold mt-1">{{ $totals['handoffs'] }}</p></div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-5"><p class="text-slate-400 text-sm">Widget opens</p><p class="text-2xl font-bold mt-1">{{ $totals['widget_opens'] }}</p></div>
    </div>

    <div class="mt-8 overflow-x-auto rounded-xl border border-slate-800">
        <table class="w-full text-sm">
            <thead class="bg-slate-900 text-slate-400 text-left">
                <tr>
                    <th class="p-4">Website</th>
                    <th class="p-4">Chats</th>
                    <th class="p-4">Leads</th>
                    <th class="p-4">Handoff %</th>
                    <th class="p-4">AI %</th>
                    <th class="p-4">Rating</th>
                </tr>
            </thead>
            <tbody>
                @foreach($summaries as $row)
                    <tr class="border-t border-slate-800">
                        <td class="p-4"><a href="{{ route('websites.analytics', $row['website']) }}" class="text-indigo-300">{{ $row['website']->name }}</a></td>
                        <td class="p-4">{{ $row['conversations'] }}</td>
                        <td class="p-4">{{ $row['leads'] }}</td>
                        <td class="p-4">{{ $row['handoff_rate'] }}%</td>
                        <td class="p-4">{{ $row['ai_resolution_rate'] }}%</td>
                        <td class="p-4">{{ $row['avg_satisfaction'] ? $row['avg_satisfaction'].'/5' : '—' }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
