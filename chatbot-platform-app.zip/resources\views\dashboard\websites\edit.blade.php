﻿@extends('layouts.app')

@section('title', 'Edit ' . $website->name)

@section('content')
@php $c = $website->configuration; $modules = $c->modules(); @endphp
<div class="max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold">Chatbot settings</h1>
    <p class="text-slate-400 mt-1">Changes apply instantly to all embedded widgets.</p>

    <form method="POST" action="{{ route('websites.update', $website) }}" class="mt-8 space-y-8">
        @csrf @method('PUT')

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 class="font-semibold text-lg">General</h2>
            <div class="grid md:grid-cols-2 gap-4">
                <div><label class="text-sm text-slate-400">Website name</label>
                    <input name="name" value="{{ old('name', $website->name) }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
                <div><label class="text-sm text-slate-400">URL</label>
                    <input name="url" value="{{ old('url', $website->url) }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
            </div>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" @checked($website->is_active)> Active</label>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 class="font-semibold text-lg">Appearance</h2>
            <div class="grid md:grid-cols-2 gap-4">
                <div><label class="text-sm text-slate-400">Bot name</label>
                    <input name="bot_name" value="{{ old('bot_name', $c->bot_name) }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
                <div><label class="text-sm text-slate-400">Avatar URL</label>
                    <input name="avatar_url" value="{{ old('avatar_url', $c->avatar_url) }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
                <div><label class="text-sm text-slate-400">Primary color</label>
                    <input name="primary_color" type="color" value="{{ old('primary_color', $c->primary_color) }}" class="w-full mt-1 h-10 rounded-lg"></div>
                <div><label class="text-sm text-slate-400">Secondary color</label>
                    <input name="secondary_color" type="color" value="{{ old('secondary_color', $c->secondary_color) }}" class="w-full mt-1 h-10 rounded-lg"></div>
                <div><label class="text-sm text-slate-400">Theme</label>
                    <select name="theme_mode" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2">
                        @foreach(['light','dark','auto'] as $t)
                            <option value="{{ $t }}" @selected($c->theme_mode === $t)>{{ ucfirst($t) }}</option>
                        @endforeach
                    </select></div>
                <div><label class="text-sm text-slate-400">Position</label>
                    <select name="position" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2">
                        <option value="right" @selected($c->position === 'right')>Right</option>
                        <option value="left" @selected($c->position === 'left')>Left</option>
                    </select></div>
            </div>
            <div><label class="text-sm text-slate-400">Welcome message</label>
                <textarea name="welcome_message" rows="3" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2">{{ old('welcome_message', $c->welcome_message) }}</textarea></div>
            <div><label class="text-sm text-slate-400">Typing indicator</label>
                <input name="typing_indicator_text" value="{{ old('typing_indicator_text', $c->typing_indicator_text) }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
            <div><label class="text-sm text-slate-400">Offline message</label>
                <textarea name="offline_message" rows="2" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2">{{ old('offline_message', $c->offline_message) }}</textarea></div>
            <div><label class="text-sm text-slate-400">Outside hours message</label>
                <textarea name="outside_hours_message" rows="2" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2">{{ old('outside_hours_message', $c->outside_hours_message) }}</textarea></div>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 class="font-semibold text-lg">AI configuration</h2>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="ai_enabled" value="1" @checked($c->ai_enabled)> Enable AI</label>
            <div class="grid md:grid-cols-3 gap-4">
                <div><label class="text-sm text-slate-400">Model</label>
                    <input name="ai_model" value="{{ old('ai_model', $c->ai_model) }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
                <div><label class="text-sm text-slate-400">Temperature</label>
                    <input name="ai_temperature" type="number" step="0.01" min="0" max="2" value="{{ old('ai_temperature', $c->ai_temperature) }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
                <div><label class="text-sm text-slate-400">Confidence threshold</label>
                    <input name="confidence_threshold" type="number" step="0.01" min="0" max="1" value="{{ old('confidence_threshold', $c->confidence_threshold) }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
            </div>
            <div><label class="text-sm text-slate-400">System prompt</label>
                <textarea name="system_prompt" rows="4" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2">{{ old('system_prompt', $c->system_prompt) }}</textarea></div>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 class="font-semibold text-lg">Modules & security</h2>
            @foreach($modules as $key => $enabled)
                <label class="flex items-center gap-2 text-sm">
                    <input type="checkbox" name="modules[{{ $key }}]" value="1" @checked($enabled)>
                    {{ str_replace('_', ' ', ucfirst($key)) }}
                </label>
            @endforeach
            <div class="grid md:grid-cols-2 gap-4 mt-4">
                <div><label class="text-sm text-slate-400">Rate limit / minute</label>
                    <input name="rate_limit_per_minute" type="number" value="{{ $c->rate_limit_per_minute }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
                <div><label class="text-sm text-slate-400">Rate limit / hour</label>
                    <input name="rate_limit_per_hour" type="number" value="{{ $c->rate_limit_per_hour }}" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2"></div>
            </div>
            <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="require_domain_validation" value="1" @checked($c->require_domain_validation)> Require allowed domains</label>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4">
            <h2 class="font-semibold text-lg">Custom code</h2>
            <div><label class="text-sm text-slate-400">Custom CSS</label>
                <textarea name="custom_css" rows="4" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 font-mono text-sm">{{ old('custom_css', $c->custom_css) }}</textarea></div>
            <div><label class="text-sm text-slate-400">Custom JS</label>
                <textarea name="custom_js" rows="4" class="w-full mt-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 font-mono text-sm">{{ old('custom_js', $c->custom_js) }}</textarea></div>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold text-lg mb-4">Q&A pairs</h2>
            @foreach($website->qaPairs as $qa)
                <div class="text-sm border-b border-slate-800 py-2 flex justify-between">
                    <span><strong>{{ $qa->question }}</strong> â†’ {{ Str::limit($qa->answer, 60) }}</span>
                    <form method="POST" action="{{ route('websites.qa.destroy', [$website, $qa]) }}">@csrf @method('DELETE')
                        <button class="text-red-400">Delete</button></form>
                </div>
            @endforeach
            <form method="POST" action="{{ route('websites.qa.store', $website) }}" class="mt-4 space-y-2">
                @csrf
                <input name="question" placeholder="Question" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
                <textarea name="answer" placeholder="Answer" rows="2" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm"></textarea>
                <input name="trigger_keywords" placeholder="Keywords (comma-separated)" class="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
                <button class="px-4 py-2 rounded-lg bg-slate-700 text-sm">Add Q&A</button>
            </form>
        </section>

        <button type="submit" class="px-6 py-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 font-medium">Save all settings</button>
    </form>
</div>
@endsection


