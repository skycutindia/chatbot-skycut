<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\OperatingHour;
use App\Models\Website;
use App\Services\AnalyticsService;
use App\Services\ChatResponseService;
use App\Services\LeadCaptureService;
use App\Services\WidgetRateLimitService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class WidgetChatController extends Controller
{
    public function __construct(
        protected ChatResponseService $chatService,
        protected AnalyticsService $analytics,
        protected WidgetRateLimitService $rateLimiter,
        protected LeadCaptureService $leadCapture,
    ) {}

    public function store(Request $request): JsonResponse
    {
        /** @var Website $website */
        $website = $request->attributes->get('website');

        if ($this->rateLimiter->tooManyAttempts($website, $request)) {
            return response()->json(['error' => 'Rate limit exceeded.'], 429);
        }

        $validated = $request->validate([
            'message' => 'required|string|max:4000',
            'visitor_id' => 'required|string|max:64',
            'conversation_id' => 'nullable|integer',
            'visitor_name' => 'nullable|string|max:120',
            'visitor_email' => 'nullable|email|max:255',
            'visitor_phone' => 'nullable|string|max:40',
            'visitor_company' => 'nullable|string|max:255',
            'page_url' => 'nullable|url|max:2048',
            'source_url' => 'nullable|url|max:2048',
            'utm_params' => 'nullable|array',
        ]);

        if (! OperatingHour::isWithinHours($website) || ! $website->is_active) {
            $msg = $website->configuration->outside_hours_message
                ?? $website->configuration->offline_message
                ?? 'We are currently offline. Please leave a message.';

            return response()->json([
                'offline' => true,
                'message' => [
                    'content' => $msg,
                    'sender_type' => 'bot',
                    'source' => 'offline',
                ],
            ]);
        }

        $conversation = $this->resolveConversation($website, $validated, $request);

        $conversation->messages()->create([
            'sender_type' => 'visitor',
            'content' => $validated['message'],
            'source' => 'user',
        ]);

        $this->analytics->track($website, 'message_sent', $request, [
            'visitor_id' => $validated['visitor_id'],
            'conversation_id' => $conversation->id,
        ]);

        if ($conversation->isAwaitingAgent()) {
            $conversation->update(['last_message_at' => now()]);

            return response()->json([
                'conversation_id' => $conversation->id,
                'handoff' => true,
                'status' => 'awaiting_agent',
                'message' => [
                    'content' => 'Your message was sent. An agent will respond shortly.',
                    'sender_type' => 'bot',
                    'source' => 'handoff_pending',
                ],
            ]);
        }

        $result = $this->chatService->respond($website, $conversation, $validated['message']);

        return response()->json(array_merge($result, [
            'conversation_id' => $conversation->id,
        ]));
    }

    public function history(Request $request): JsonResponse
    {
        /** @var Website $website */
        $website = $request->attributes->get('website');

        $validated = $request->validate([
            'visitor_id' => 'required|string|max:64',
            'conversation_id' => 'nullable|integer',
        ]);

        $conversation = Conversation::query()
            ->where('website_id', $website->id)
            ->where('visitor_id', $validated['visitor_id'])
            ->when($validated['conversation_id'] ?? null, fn ($q, $id) => $q->where('id', $id))
            ->latest('last_message_at')
            ->first();

        if (! $conversation) {
            return response()->json(['messages' => []]);
        }

        return response()->json([
            'conversation_id' => $conversation->id,
            'mode' => $conversation->mode,
            'status' => $conversation->status,
            'messages' => $conversation->messages->map(fn (Message $m) => [
                'id' => $m->id,
                'content' => $m->content,
                'sender_type' => $m->sender_type,
                'source' => $m->source,
                'created_at' => $m->created_at->toIso8601String(),
            ]),
        ]);
    }

    public function poll(Request $request): JsonResponse
    {
        /** @var Website $website */
        $website = $request->attributes->get('website');

        $validated = $request->validate([
            'visitor_id' => 'required|string|max:64',
            'conversation_id' => 'required|integer',
            'after_id' => 'nullable|integer',
        ]);

        $conversation = Conversation::query()
            ->where('website_id', $website->id)
            ->where('visitor_id', $validated['visitor_id'])
            ->where('id', $validated['conversation_id'])
            ->first();

        if (! $conversation) {
            return response()->json(['messages' => [], 'status' => 'closed']);
        }

        $afterId = (int) ($validated['after_id'] ?? 0);

        $messages = $conversation->messages()
            ->when($afterId > 0, fn ($q) => $q->where('id', '>', $afterId))
            ->whereIn('sender_type', ['bot', 'agent'])
            ->get()
            ->map(fn (Message $m) => [
                'id' => $m->id,
                'content' => $m->content,
                'sender_type' => $m->sender_type,
                'source' => $m->source,
                'created_at' => $m->created_at->toIso8601String(),
            ]);

        return response()->json([
            'messages' => $messages,
            'status' => $conversation->status,
            'mode' => $conversation->mode,
            'handoff' => $conversation->isAwaitingAgent(),
        ]);
    }

    protected function resolveConversation(Website $website, array $validated, Request $request): Conversation
    {
        if (! empty($validated['conversation_id'])) {
            $existing = Conversation::query()
                ->where('website_id', $website->id)
                ->where('visitor_id', $validated['visitor_id'])
                ->where('id', $validated['conversation_id'])
                ->whereIn('status', ['open', 'awaiting_agent'])
                ->first();

            if ($existing) {
                return $this->leadCapture->enrichConversation($existing, $validated, $request);
            }
        }

        $open = Conversation::query()
            ->where('website_id', $website->id)
            ->where('visitor_id', $validated['visitor_id'])
            ->whereIn('status', ['open', 'awaiting_agent'])
            ->latest('last_message_at')
            ->first();

        if ($open) {
            return $this->leadCapture->enrichConversation($open, $validated, $request);
        }

        $conversation = Conversation::create([
            'website_id' => $website->id,
            'visitor_id' => $validated['visitor_id'],
            'visitor_name' => $validated['visitor_name'] ?? null,
            'visitor_email' => $validated['visitor_email'] ?? null,
            'visitor_phone' => $validated['visitor_phone'] ?? null,
            'visitor_company' => $validated['visitor_company'] ?? null,
            'page_url' => $validated['page_url'] ?? null,
            'source_url' => $validated['source_url'] ?? $validated['page_url'] ?? null,
            'utm_params' => $validated['utm_params'] ?? null,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'status' => 'open',
            'mode' => 'ai',
            'last_message_at' => now(),
        ]);

        $this->leadCapture->captureFromConversation($website, $conversation, $request);

        return $conversation;
    }
}
