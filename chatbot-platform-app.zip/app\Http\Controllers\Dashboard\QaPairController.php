<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\QaPair;
use App\Models\Website;
use App\Services\WidgetConfigService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class QaPairController extends Controller
{
    public function store(Request $request, Website $website, WidgetConfigService $config): RedirectResponse
    {
        $validated = $request->validate([
            'question' => 'required|string|max:500',
            'answer' => 'required|string|max:5000',
            'trigger_keywords' => 'nullable|string',
            'priority' => 'nullable|integer|min:0|max:100',
        ]);

        $keywords = array_filter(array_map('trim', explode(',', $validated['trigger_keywords'] ?? '')));

        $website->qaPairs()->create([
            'question' => $validated['question'],
            'answer' => $validated['answer'],
            'trigger_keywords' => $keywords ?: null,
            'priority' => $validated['priority'] ?? 0,
        ]);

        $config->invalidate($website);

        return back()->with('success', 'Q&A pair added.');
    }

    public function destroy(Website $website, QaPair $qaPair, WidgetConfigService $config): RedirectResponse
    {
        abort_unless($qaPair->website_id === $website->id, 404);
        $qaPair->delete();
        $config->invalidate($website);

        return back()->with('success', 'Q&A pair removed.');
    }
}
