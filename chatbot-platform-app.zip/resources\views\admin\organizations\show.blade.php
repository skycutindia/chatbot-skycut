@extends('layouts.app')

@section('title', $organization->name)

@section('content')
<div class="max-w-5xl mx-auto">
    <a href="{{ route('admin.organizations.index') }}" class="text-sm text-indigo-400">← Organizations</a>
    <h1 class="text-3xl font-bold mt-4">{{ $organization->name }}</h1>
    <p class="text-slate-400">{{ $organization->slug }}</p>

    <form method="POST" action="{{ route('admin.organizations.update', $organization) }}" class="mt-8 rounded-xl bg-slate-900 border border-slate-800 p-6 space-y-4 max-w-lg">
        @csrf @method('PATCH')
        <div>
            <label class="text-sm text-slate-400">Name</label>
            <input name="name" value="{{ $organization->name }}" class="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        </div>
        <div>
            <label class="text-sm text-slate-400">Timezone</label>
            <input name="timezone" value="{{ $organization->timezone }}" class="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm">
        </div>
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" @checked($organization->is_active)> Active</label>
        <button class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">Save</button>
    </form>

    <div class="grid md:grid-cols-2 gap-6 mt-8">
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold">Websites ({{ $organization->websites->count() }})</h2>
            <ul class="mt-3 space-y-2 text-sm">
                @foreach($organization->websites as $site)
                    <li class="flex justify-between"><span>{{ $site->name }}</span><span class="text-slate-500">{{ $site->configuration?->bot_name }}</span></li>
                @endforeach
            </ul>
        </div>
        <div class="rounded-xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold">Team ({{ $organization->users->count() }})</h2>
            <ul class="mt-3 space-y-2 text-sm">
                @foreach($organization->users as $user)
                    <li class="flex justify-between"><span>{{ $user->name }}</span><span class="text-slate-500">{{ $user->role }}</span></li>
                @endforeach
            </ul>
        </div>
    </div>
</div>
@endsection
