@extends('layouts.app')

@section('title', 'Team')

@section('content')
<div class="max-w-4xl mx-auto">
    <div class="flex justify-between items-center">
        <div>
            <h1 class="text-3xl font-bold">Team</h1>
            <p class="text-slate-400 mt-1">Manage users and roles for your organization</p>
        </div>
        <a href="{{ route('team.create') }}" class="px-4 py-2 rounded-lg bg-indigo-600 text-sm">+ Add member</a>
    </div>

    <div class="mt-6 overflow-x-auto rounded-xl border border-slate-800">
        <table class="w-full text-sm">
            <thead class="bg-slate-900 text-slate-400 text-left">
                <tr><th class="p-4">Name</th><th class="p-4">Email</th><th class="p-4">Role</th><th class="p-4">Status</th><th class="p-4"></th></tr>
            </thead>
            <tbody>
                @foreach($members as $member)
                    <tr class="border-t border-slate-800">
                        <td class="p-4 font-medium">{{ $member->name }}</td>
                        <td class="p-4 text-slate-400">{{ $member->email }}</td>
                        <td class="p-4"><span class="text-xs px-2 py-1 rounded bg-slate-800">{{ $member->roleEnum()->label() }}</span></td>
                        <td class="p-4">{{ $member->is_active ? 'Active' : 'Inactive' }}</td>
                        <td class="p-4 text-right">
                            <a href="{{ route('team.edit', $member) }}" class="text-indigo-400 text-sm">Edit</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="mt-4">{{ $members->links() }}</div>
</div>
@endsection
