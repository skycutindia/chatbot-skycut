@extends('layouts.app')

@section('title', 'Embed — '.$website->name)

@section('content')
<div class="max-w-5xl mx-auto">
    <a href="{{ route('websites.show', $website) }}" class="text-sm text-indigo-400">← Back to website</a>
    <h1 class="text-3xl font-bold mt-4">Widget Download Center</h1>
    <p class="text-slate-400 mt-1">Deploy {{ $website->name }} on any platform</p>

    <div class="mt-8 space-y-8">
        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold text-lg">Standard embed (recommended)</h2>
            <p class="text-sm text-slate-400 mt-1">Paste before <code>&lt;/body&gt;</code> on any HTML site.</p>
            <pre class="mt-4 p-4 rounded-lg bg-slate-950 text-emerald-300 text-xs overflow-x-auto"><code>{{ $embedSnippet }}</code></pre>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold text-lg">Simple script tag</h2>
            <pre class="mt-4 p-4 rounded-lg bg-slate-950 text-emerald-300 text-xs overflow-x-auto"><code>{{ $simpleSnippet }}</code></pre>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold text-lg">WordPress</h2>
            <pre class="mt-4 p-4 rounded-lg bg-slate-950 text-slate-300 text-xs overflow-x-auto"><code>{{ $wordpressSnippet }}</code></pre>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold text-lg">Shopify</h2>
            <pre class="mt-4 p-4 rounded-lg bg-slate-950 text-slate-300 text-xs overflow-x-auto"><code>{{ $shopifySnippet }}</code></pre>
        </section>

        <section class="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h2 class="font-semibold text-lg">Website key</h2>
            <p class="text-sm text-slate-400 mt-2">Use this key in the <code>aichatbot('init', ...)</code> call:</p>
            <code class="block mt-2 text-indigo-300">{{ $website->bot_token }}</code>
            <p class="text-sm text-slate-500 mt-4">Verification token: {{ $website->verification_token }}</p>
        </section>
    </div>
</div>
@endsection
