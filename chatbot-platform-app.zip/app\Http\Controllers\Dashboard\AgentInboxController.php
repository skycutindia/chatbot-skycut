<?php

namespace App\Http\Controllers\Dashboard;

use App\Events\ConversationUpdated;
use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Website;
use App\Services\LiveHandoffService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AgentInboxController extends Controller
{
    public function index(Request $request): View
    {
        $orgId = $request->user()->organization_id;

        $query = Conversation::query()
            ->with(['website', 'assignedUser']);

        if ($orgId) {
            $query->whereHas('website', fn ($q) => $q->where('organization_id', $orgId));
        }

        $conversations = $query
            ->when($request->status, fn ($q, $s) => $q->where('status', $s), fn ($q) => $q->whereIn('status', ['open', 'awaiting_agent']))
            ->when($request->user()->roleEnum()->value === 'agent', fn ($q) => $q->where(function ($inner) use ($request) {
                $inner->whereNull('assigned_user_id')->orWhere('assigned_user_id', $request->user()->id);
            }))
            ->latest('last_message_at')
            ->paginate(30)
            ->withQueryString();

        return view('dashboard.inbox.index', compact('conversations'));
    }

    public function poll(Request $request): JsonResponse
    {
        $orgId = $request->user()->organization_id;
        $query = Conversation::query()->with(['website:id,name']);

        if ($orgId) {
            $query->whereHas('website', fn ($q) => $q->where('organization_id', $orgId));
        }

        $conversations = $query
            ->whereIn('status', ['open', 'awaiting_agent'])
            ->when($request->user()->roleEnum()->value === 'agent', fn ($q) => $q->where(function ($inner) use ($request) {
                $inner->whereNull('assigned_user_id')->orWhere('assigned_user_id', $request->user()->id);
            }))
            ->latest('last_message_at')
            ->limit(20)
            ->get()
            ->map(fn (Conversation $c) => [
                'id' => $c->id,
                'website' => $c->website?->name,
                'website_id' => $c->website_id,
                'visitor_name' => $c->visitor_name,
                'status' => $c->status,
                'mode' => $c->mode,
                'last_message_at' => $c->last_message_at?->diffForHumans(),
                'awaiting' => $c->status === 'awaiting_agent',
            ]);

        return response()->json([
            'count' => $conversations->count(),
            'awaiting' => $conversations->where('awaiting', true)->count(),
            'conversations' => $conversations,
        ]);
    }

    public function assign(Request $request, Conversation $conversation): RedirectResponse
    {
        $this->authorizeConversation($conversation);
        $conversation->update(['assigned_user_id' => $request->user()->id, 'status' => 'open']);
        broadcast(new ConversationUpdated($conversation->fresh(), 'assigned'));

        return back()->with('success', 'Conversation assigned to you.');
    }

    public function close(Conversation $conversation): RedirectResponse
    {
        $this->authorizeConversation($conversation);
        $conversation->update(['status' => 'closed', 'closed_at' => now()]);
        broadcast(new ConversationUpdated($conversation->fresh(), 'closed'));

        return back()->with('success', 'Conversation closed.');
    }

    public function reopen(Conversation $conversation): RedirectResponse
    {
        $this->authorizeConversation($conversation);
        $conversation->update(['status' => 'open', 'closed_at' => null, 'last_message_at' => now()]);

        return back()->with('success', 'Conversation reopened.');
    }

    public function returnToAi(Conversation $conversation, LiveHandoffService $handoff): RedirectResponse
    {
        $this->authorizeConversation($conversation);
        $handoff->returnToAi($conversation);

        return back()->with('success', 'AI has resumed this conversation.');
    }

    protected function authorizeConversation(Conversation $conversation): void
    {
        abort_unless(
            $conversation->website->organization_id === auth()->user()->organization_id,
            403
        );
    }
}
